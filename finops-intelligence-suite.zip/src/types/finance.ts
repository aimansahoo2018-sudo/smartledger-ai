export enum CostType {
  DIRECT = 'Direct',
  INDIRECT = 'Indirect'
}

export enum CostBehavior {
  FIXED = 'Fixed',
  VARIABLE = 'Variable',
  SEMIVARIABLE = 'Semi-variable'
}

export interface Expense {
  id: string;
  vendor: string;
  amount: number;
  date: string;
  description: string;
  category?: string;
  costType?: CostType;
  costBehavior?: CostBehavior;
  costCenter?: string;
  confidence?: number;
  isAnomaly?: boolean;
  anomalyReason?: string;
}

export interface FinancialFigures {
  // Balance Sheet
  currentAssets: number;
  inventory: number;
  cashAndEquivalents: number;
  currentLiabilities: number;
  totalAssets: number;
  totalEquity: number;
  totalDebt: number;
  
  // P&L
  revenue: number;
  cosm: number; // Cost of Sales/Materials
  ebit: number;
  interestExpense: number;
  netIncome: number;
}

export interface FinancialRatios {
  liquidity: {
    current: number;
    quick: number;
    cash: number;
  };
  profitability: {
    gpm: number;
    npm: number;
    roa: number;
    roe: number;
    roce: number;
  };
  efficiency: {
    assetTurnover: number;
    inventoryDays: number;
    receivableDays: number;
    payableDays: number;
  };
  leverage: {
    debtToEquity: number;
    interestCoverage: number;
  };
}
