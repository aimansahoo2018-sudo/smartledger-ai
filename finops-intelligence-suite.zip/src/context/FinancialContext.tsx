import React, { createContext, useContext, useState, ReactNode } from 'react';

export enum CostType {
  DIRECT = 'Direct',
  INDIRECT = 'Indirect'
}

export enum CostBehavior {
  VARIABLE = 'Variable',
  FIXED = 'Fixed'
}

export interface Expense {
  id: string;
  vendor: string;
  amount: number;
  date: string;
  description: string;
  costType: CostType;
  costBehavior: CostBehavior;
  costCenter: string;
  confidence?: number;
  isAnomaly?: boolean;
  anomalyReason?: string;
}

interface FinancialContextType {
  expenses: Expense[];
  addExpense: (expense: Expense) => void;
  addExpenses: (expenses: Expense[]) => void;
  currency: string;
  setCurrency: (c: string) => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  timeframe: string;
  setTimeframe: (timeframe: string) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  formatCurrency: (amount: number) => string;
  totals: {
    revenue: number;
    expenses: number;
    pendingInvoices: number;
    taxEstimate: number;
  };
}

const FinancialContext = createContext<FinancialContextType | undefined>(undefined);

const CURRENCIES = [
  { code: 'INR', symbol: '₹', rate: 1, locale: 'en-IN' },
  { code: 'PKR', symbol: 'Rs', rate: 3.35, locale: 'en-PK' },
  { code: 'USD', symbol: '$', rate: 0.012, locale: 'en-US' },
  { code: 'EUR', symbol: '€', rate: 0.011, locale: 'en-DE' },
  { code: 'GBP', symbol: '£', rate: 0.0094, locale: 'en-GB' },
  { code: 'AED', symbol: 'د.إ', rate: 0.044, locale: 'ar-AE' },
];

export function FinancialProvider({ children }: { children: ReactNode }) {
  const [currency, setCurrency] = useState('PKR');
  const [activeTab, setActiveTab] = useState('dashboard');
  const [timeframe, setTimeframe] = useState('This Year');
  const [searchQuery, setSearchQuery] = useState('');
  const [expenses, setExpenses] = useState<Expense[]>([
    {
      id: '1',
      vendor: 'AWS Cloud Services',
      amount: 1420.50,
      date: '2024-05-12',
      description: 'Monthly production infrastructure hosting',
      costType: CostType.DIRECT,
      costBehavior: CostBehavior.VARIABLE,
      costCenter: 'Engineering',
      confidence: 0.98
    },
    {
      id: '2',
      vendor: 'WeWork Office Space',
      amount: 4500.00,
      date: '2024-05-10',
      description: 'HQ Regional Office Rent',
      costType: CostType.INDIRECT,
      costBehavior: CostBehavior.FIXED,
      costCenter: 'Operations',
      confidence: 0.99
    },
    {
      id: '3',
      vendor: 'Unknown Vendor X',
      amount: 890.00,
      date: '2024-05-15',
      description: 'Uncategorized high-value transaction',
      costType: CostType.INDIRECT,
      costBehavior: CostBehavior.VARIABLE,
      costCenter: 'Sales',
      confidence: 0.45,
      isAnomaly: true,
      anomalyReason: 'Transaction amount exceeds historical vendor baseline by 400%.'
    }
  ]);

  const addExpense = (newExpense: Expense) => {
    setExpenses(prev => [newExpense, ...prev]);
  };

  const addExpenses = (newExpenses: Expense[]) => {
    setExpenses(prev => [...newExpenses, ...prev]);
  };

  const formatCurrency = (amount: number) => {
    const selected = CURRENCIES.find(c => c.code === currency) || CURRENCIES[0];
    const converted = amount * selected.rate;
    return new Intl.NumberFormat(selected.locale, {
      style: 'currency',
      currency: selected.code,
      maximumFractionDigits: 0,
    }).format(converted);
  };

  // Mock revenue for dashboard
  const revenue = 842300;
  const totalExpenses = expenses.reduce((sum, item) => sum + item.amount, 0);
  const pendingInvoices = 125000;
  const taxEstimate = totalExpenses * 0.18; // Simple 18% tax estimate logic

  return (
    <FinancialContext.Provider value={{ 
      expenses, 
      addExpense, 
      addExpenses,
      currency,
      setCurrency,
      activeTab,
      setActiveTab,
      timeframe,
      setTimeframe,
      searchQuery,
      setSearchQuery,
      formatCurrency,
      totals: {
        revenue,
        expenses: totalExpenses,
        pendingInvoices,
        taxEstimate
      }
    }}>
      {children}
    </FinancialContext.Provider>
  );
}

export function useFinancial() {
  const context = useContext(FinancialContext);
  if (context === undefined) {
    throw new Error('useFinancial must be used within a FinancialProvider');
  }
  return context;
}
