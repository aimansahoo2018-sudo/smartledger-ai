import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function classifyExpenses(expenses: any[]) {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Classify the following list of expenses. For each expense, provide:
    1. costType (Direct/Indirect)
    2. costBehavior (Fixed/Variable/Semi-variable)
    3. costCenter (Production, Admin, Sales, R&D, Logistics)
    4. isAnomaly (boolean)
    5. anomalyReason (string, if anomaly)
    6. confidence (0-1 score)

    Expenses: ${JSON.stringify(expenses)}`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            id: { type: Type.STRING },
            costType: { type: Type.STRING },
            costBehavior: { type: Type.STRING },
            costCenter: { type: Type.STRING },
            isAnomaly: { type: Type.BOOLEAN },
            anomalyReason: { type: Type.STRING },
            confidence: { type: Type.NUMBER }
          },
          required: ["id", "costType", "costBehavior", "costCenter", "isAnomaly", "confidence"]
        }
      }
    }
  });

  return JSON.parse(response.text);
}

export async function interpretFinancialRatios(ratios: any, figures: any) {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `As a senior CMA finance professional, interpret these financial ratios and figures.
    Context:
    Figures: ${JSON.stringify(figures)}
    Ratios: ${JSON.stringify(ratios)}

    Provide:
    1. A concise executive narrative (2-3 paragraphs).
    2. Health status for each ratio category (GREEN/AMBER/RED).
    3. Specific areas of concern or opportunities for improvement.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          narrative: { type: Type.STRING },
          healthIndicators: {
            type: Type.OBJECT,
            properties: {
              liquidity: { type: Type.STRING },
              profitability: { type: Type.STRING },
              efficiency: { type: Type.STRING },
              leverage: { type: Type.STRING }
            }
          },
          recommendations: {
            type: Type.ARRAY,
            items: { type: Type.STRING }
          }
        },
        required: ["narrative", "healthIndicators", "recommendations"]
      }
    }
  });

  return JSON.parse(response.text);
}

export async function generateExecutiveInsight(context: string) {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `As a senior CMA finance analytic bot, analyze this data and provide exactly 5 sharp, professional executive bullet points summarizing the most critical findings and action items.
    
    Data Context: ${context}
    
    Output exactly 5 bullets in string array format.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          bullets: {
            type: Type.ARRAY,
            items: { type: Type.STRING }
          }
        },
        required: ["bullets"]
      }
    }
  });

  return JSON.parse(response.text).bullets;
}

export async function chatWithFinanceAI(history: { role: string; parts: string }[], context?: string) {
  const chat = ai.chats.create({
    model: "gemini-3-flash-preview",
    config: {
      systemInstruction: `You are a senior CMA financial strategic assistant for SmartLedger AI. 
      Provide sharp, professional, and strategic fiscal advice.
      ${context ? `Here is the current financial context to inform your answers: ${context}` : ''}
      Always be concise, data-driven, and strategic. If asked about specific figures, refer to the provided context.`,
    },
    history: history.slice(0, -1).map(h => ({
      role: h.role,
      parts: [{ text: h.parts }]
    }))
  });

  const lastMessage = history[history.length - 1].parts;
  const response = await chat.sendMessage({ message: lastMessage });
  return response.text;
}

export const getHealthColor = (status: string) => {
  switch (status) {
    case 'GREEN': return 'text-emerald-500 bg-emerald-500/10 border-emerald-500/20';
    case 'AMBER': return 'text-amber-500 bg-amber-500/10 border-amber-500/20';
    case 'RED': return 'text-rose-500 bg-rose-500/10 border-rose-500/20';
    default: return 'text-slate-500 bg-slate-800 border-slate-700';
  }
};
