
export interface ReportData {
  title: string;
  summary: { label: string; value: string }[];
  aiInsights: string[];
  tableData: any[];
}

export function printReport(data: ReportData) {
  const date = new Date().toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  const html = `
    <!DOCTYPE html>
    <html>
      <head>
        <title>${data.title}</title>
        <style>
          @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&family=JetBrains+Mono:wght@500&display=swap');
          body {
            font-family: 'Inter', sans-serif;
            color: #1e293b;
            line-height: 1.5;
            padding: 40px;
            max-width: 900px;
            margin: 0 auto;
          }
          .header {
            border-bottom: 2px solid #3b82f6;
            padding-bottom: 20px;
            margin-bottom: 40px;
            display: flex;
            justify-content: space-between;
            align-items: flex-end;
          }
          .header h1 {
            margin: 0;
            font-size: 24px;
            text-transform: uppercase;
            letter-spacing: 0.1em;
            color: #0f172a;
          }
          .meta {
            text-align: right;
            font-size: 12px;
            color: #64748b;
          }
          .summary-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            margin-bottom: 40px;
          }
          .summary-card {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            padding: 20px;
            border-radius: 8px;
          }
          .summary-card label {
            display: block;
            font-size: 10px;
            text-transform: uppercase;
            font-weight: 700;
            color: #64748b;
            margin-bottom: 8px;
            letter-spacing: 0.05em;
          }
          .summary-card span {
            font-size: 18px;
            font-weight: 700;
            color: #1e293b;
            font-family: 'JetBrains Mono', monospace;
          }
          .section {
            margin-bottom: 40px;
          }
          .section-title {
            font-size: 14px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.1em;
            color: #3b82f6;
            margin-bottom: 20px;
            border-left: 4px solid #3b82f6;
            padding-left: 12px;
          }
          .insights-list {
            padding: 0;
            list-style: none;
          }
          .insights-list li {
            background: #eff6ff;
            border: 1px solid #dbeafe;
            padding: 15px;
            margin-bottom: 12px;
            border-radius: 6px;
            font-size: 13px;
            font-style: italic;
          }
          table {
            width: 100%;
            border-collapse: collapse;
            font-size: 12px;
          }
          th {
            background: #f1f5f9;
            text-align: left;
            padding: 12px;
            border-bottom: 2px solid #e2e8f0;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.05em;
          }
          td {
            padding: 12px;
            border-bottom: 1px solid #f1f5f9;
          }
          .footer {
            margin-top: 60px;
            padding-top: 20px;
            border-top: 1px solid #e2e8f0;
            font-size: 10px;
            color: #94a3b8;
            display: flex;
            justify-content: space-between;
          }
          @media print {
            body { padding: 0; }
            .no-print { display: none; }
          }
        </style>
      </head>
      <body>
        <div class="header">
          <div>
            <h1>FinOps Intelligence</h1>
            <p style="margin: 5px 0 0; font-size: 12px; color: #64748b;">${data.title}</p>
          </div>
          <div class="meta">
            <div>Prepared for: Strategic Finance Unit</div>
            <div>Generated: ${date}</div>
          </div>
        </div>

        <div class="summary-grid">
          ${data.summary.map(s => `
            <div class="summary-card">
              <label>${s.label}</label>
              <span>${s.value}</span>
            </div>
          `).join('')}
        </div>

        ${data.aiInsights.length > 0 ? `
          <div class="section">
            <div class="section-title">Executive AI Insights</div>
            <ul class="insights-list">
              ${data.aiInsights.map(insight => `<li>${insight}</li>`).join('')}
            </ul>
          </div>
        ` : ''}

        <div class="section">
          <div class="section-title">Data Granularity View</div>
          <table>
            <thead>
              <tr>
                ${Object.keys(data.tableData[0] || {}).map(key => `<th>${key}</th>`).join('')}
              </tr>
            </thead>
            <tbody>
              ${data.tableData.map(row => `
                <tr>
                  ${Object.values(row).map(val => `<td>${val}</td>`).join('')}
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>

        <div class="footer">
          <div>CORPORATE CONFIDENTIAL | FinOps Accelerator ${new Date().getFullYear()}</div>
          <div>Prepared by: Finance Team Intelligence Layer</div>
        </div>

        <script>
          window.onload = () => {
            // Uncomment to auto-print
            // window.print();
          };
        </script>
      </body>
    </html>
  `;

  const printWindow = window.open('', '_blank');
  if (printWindow) {
    printWindow.document.write(html);
    printWindow.document.close();
  }
}
