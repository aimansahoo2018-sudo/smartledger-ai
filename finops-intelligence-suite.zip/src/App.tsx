/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { Sidebar } from './components/Sidebar';
import { TopBar } from './components/TopBar';
import { CostClassifier } from './components/CostClassifier';
import { RatioInterpreter } from './components/RatioInterpreter';
import { AiAssistant } from './components/AiAssistant';
import { InvoiceManager } from './components/InvoiceManager';
import { ClientManager } from './components/ClientManager';
import { TaxDashboard } from './components/TaxDashboard';
import { DashboardHome } from './components/dashboard/DashboardHome';
import { FloatingAiButton } from './components/FloatingAiButton';
import { motion, AnimatePresence } from 'motion/react';
import { useFinancial } from './context/FinancialContext';

export default function App() {
  const { activeTab, setActiveTab } = useFinancial();

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <DashboardHome />;
      case 'invoices':
        return <InvoiceManager />;
      case 'clients':
        return <ClientManager />;
      case 'expenses':
        return <CostClassifier />;
      case 'reports':
        return <RatioInterpreter />;
      case 'taxes':
        return <TaxDashboard />;
      case 'ai-assistant':
        return <AiAssistant />;
      default:
        return (
          <div className="flex flex-col items-center justify-center h-[60vh] text-slate-400">
            <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mb-4">
              <span className="text-2xl opacity-50">?</span>
            </div>
            <p className="font-bold text-sm uppercase tracking-widest">Module Under Construction</p>
            <p className="text-xs mt-2 italic">The functional core of this section is being synchronized.</p>
            <button 
              onClick={() => setActiveTab('dashboard')}
              className="mt-6 text-primary font-bold text-[10px] uppercase tracking-widest hover:underline"
            >
              Return to Dashboard
            </button>
          </div>
        );
    }
  };

  return (
    <div className="flex bg-secondary min-h-screen selection:bg-primary/20 selection:text-primary">
      {/* Fixed Sidebar */}
        <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />

        {/* Main Content Area */}
        <main className="flex-1 ml-64 min-h-screen relative flex flex-col">
          <TopBar title={activeTab.charAt(0).toUpperCase() + activeTab.slice(1)} />
          
          <div className="px-8 pb-12 flex-1">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
                transition={{ duration: 0.3, ease: [0.23, 1, 0.32, 1] }}
              >
                {renderContent()}
              </motion.div>
            </AnimatePresence>
          </div>

          <FloatingAiButton />

          {/* Footer info */}
          <footer className="px-8 py-6 border-t border-border-warm flex justify-between items-center text-[10px] font-bold text-slate-400 uppercase tracking-widest">
            <div className="flex gap-8">
              <div className="flex items-center gap-2">
                <div className="h-1.5 w-1.5 rounded-full bg-accent-emerald"></div>
                <span>Status: Operational</span>
              </div>
              <span>Business Plan Active</span>
            </div>
            <div className="flex gap-8">
              <span>© 2026 SmartLedger AI</span>
              <span className="text-primary/70">v3.0.0 Global Stable</span>
            </div>
          </footer>
        </main>
      </div>
  );
}

