import { useState, useMemo, useRef } from 'react';
import { Upload, AlertTriangle, CheckCircle2, ChevronRight, PieChart, Activity, Info, FileUp, Sparkles, TrendingUp, DollarSign, Download, Loader2, ShieldAlert, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  PieChart as RechartsPie, Pie, Cell, ResponsiveContainer, 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend 
} from 'recharts';
import { CostType, CostBehavior, useFinancial } from '../context/FinancialContext';
import { classifyExpenses, generateExecutiveInsight } from '../services/geminiService';
import { printReport } from '../services/reportGenerator';

export function CostClassifier() {
  const { expenses, addExpenses, formatCurrency, searchQuery } = useFinancial();
  const [inputText, setInputText] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [inputError, setInputError] = useState<string | null>(null);
  const [aiInsights, setAiInsights] = useState<string[] | null>(null);
  const [isGeneratingInsight, setIsGeneratingInsight] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const filteredExpenses = useMemo(() => {
    return expenses.filter(e => 
      e.vendor.toLowerCase().includes(searchQuery.toLowerCase()) ||
      e.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      e.costCenter.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [expenses, searchQuery]);

  const handleProcessRawData = async (rawInput: string) => {
    setIsProcessing(true);
    setInputError(null);
    try {
      const lines = rawInput.split('\n').filter(l => l.trim());
      
      const rawExpenses = lines.map((line, i) => {
        const parts = line.split(',');
        if (parts.length < 2) {
          throw new Error(`Invalid format on line ${i + 1}. Expected: Vendor, Amount, ...`);
        }
        const amount = parseFloat(parts[1].trim());
        if (isNaN(amount)) {
          throw new Error(`Invalid amount on line ${i + 1}: ${parts[1]}`);
        }

        return {
          id: `new-${Date.now()}-${i}`,
          vendor: parts[0]?.trim() || 'Unknown',
          amount: amount,
          date: parts[2]?.trim() || new Date().toISOString().split('T')[0],
          description: parts[3]?.trim() || 'Raw input'
        };
      });

      const results = await classifyExpenses(rawExpenses);
      
      const updatedExpenses = rawExpenses.map(raw => {
        const result = results.find((r: any) => r.id === raw.id);
        return { ...raw, ...result };
      });

      addExpenses(updatedExpenses as any);
    } catch (error: any) {
      console.error(error);
      setInputError(error.message || 'Failed to process input');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleExportReport = () => {
    printReport({
      title: 'Cost Classification Analysis',
      summary: [
        { label: 'Total Spend', value: formatCurrency(summaryData.totalSpend) },
        { label: 'Anomalies', value: summaryData.anomaliesCount.toString() },
        { label: 'Primary Center', value: summaryData.topCostCenter },
      ],
      aiInsights: aiInsights || [],
      tableData: expenses.map(e => ({
        'Vendor': e.vendor,
        'Type': e.costType || 'N/A',
        'Center': e.costCenter || 'N/A',
        'Amount': formatCurrency(e.amount),
        'Status': e.isAnomaly ? 'ANOMALY' : 'NORMAL'
      }))
    });
  };

  const handleProcess = () => {
    if (!inputText.trim()) return;
    handleProcessRawData(inputText);
    setInputText('');
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const text = e.target?.result as string;
        handleProcessRawData(text);
      };
      reader.readAsText(file);
    }
  };

  const handleGenerateInsight = async () => {
    setIsGeneratingInsight(true);
    try {
      const context = `Expenses: ${JSON.stringify(expenses.map(e => ({ v: e.vendor, a: e.amount, c: e.costCenter, t: e.costType, b: e.costBehavior, anomaly: e.isAnomaly })))}`;
      const insights = await generateExecutiveInsight(context);
      setAiInsights(insights);
    } catch (err) {
      console.error(err);
    } finally {
      setIsGeneratingInsight(false);
    }
  };

  const summaryData = useMemo(() => {
    const totalSpend = expenses.reduce((sum, e) => sum + e.amount, 0);
    const anomaliesCount = expenses.filter(e => e.isAnomaly).length;
    const centers = expenses.reduce((acc: any, curr) => {
      const label = curr.costCenter || 'N/A';
      acc[label] = (acc[label] || 0) + curr.amount;
      return acc;
    }, {});
    const topCostCenter = Object.entries(centers).sort((a: any, b: any) => b[1] - a[1])[0]?.[0] || 'N/A';

    return { totalSpend, anomaliesCount, topCostCenter };
  }, [expenses]);

  const costTypeData = useMemo(() => {
    const types = expenses.reduce((acc: any, curr) => {
      const label = curr.costType || 'Unclassified';
      acc[label] = (acc[label] || 0) + curr.amount;
      return acc;
    }, {});
    return Object.entries(types).map(([name, value]) => ({ name, value }));
  }, [expenses]);

  const costCenterData = useMemo(() => {
    const centers = expenses.reduce((acc: any, curr) => {
      const label = curr.costCenter || 'N/A';
      acc[label] = (acc[label] || 0) + curr.amount;
      return acc;
    }, {});
    return Object.entries(centers).map(([name, value]) => ({ name, value }));
  }, [expenses]);

  const anomalies = expenses.filter(e => e.isAnomaly);
  const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'];

  return (
    <div className="space-y-6">
      {/* Summary Panel */}
      <div className="flex justify-between items-center mb-2">
        <h2 className="text-xs font-bold text-slate-400 uppercase tracking-[0.2em]">Operational Financial Intelligence</h2>
        <button 
          onClick={handleExportReport}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white hover:bg-slate-50 text-slate-700 text-[11px] font-bold uppercase tracking-widest border border-border-warm shadow-sm transition-all"
        >
          <Download className="w-3.5 h-3.5 text-primary" />
          Export Report
        </button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="dashboard-card p-6 border-l-4 border-primary">
          <p className="text-[11px] uppercase tracking-widest text-slate-400 mb-1 font-bold">Total Aggregated Spend</p>
          <div className="flex items-end justify-between">
            <span className="text-3xl font-extrabold text-[#1A202C] tracking-tight">{formatCurrency(summaryData.totalSpend)}</span>
            <div className="p-2 bg-primary/10 rounded-lg">
              <DollarSign className="w-5 h-5 text-primary" />
            </div>
          </div>
        </div>
        <div className="dashboard-card p-6 border-l-4 border-accent-rose">
          <p className="text-[11px] uppercase tracking-widest text-slate-400 mb-1 font-bold">Integrity Anomalies</p>
          <div className="flex items-end justify-between">
            <span className="text-3xl font-extrabold text-accent-rose tracking-tight">{summaryData.anomaliesCount.toString().padStart(2, '0')}</span>
            <div className="p-2 bg-accent-rose/10 rounded-lg">
              <AlertTriangle className="w-5 h-5 text-accent-rose" />
            </div>
          </div>
        </div>
        <div className="dashboard-card p-6 border-l-4 border-accent-emerald">
          <p className="text-[11px] uppercase tracking-widest text-slate-400 mb-1 font-bold">Primary Cost Center</p>
          <div className="flex items-end justify-between">
            <span className="text-2xl font-extrabold text-accent-emerald truncate mt-1">{summaryData.topCostCenter}</span>
            <div className="p-2 bg-accent-emerald/10 rounded-lg">
              <Activity className="w-5 h-5 text-accent-emerald" />
            </div>
          </div>
        </div>
      </div>

      {/* Input & AI Box */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-3 dashboard-card overflow-hidden flex flex-col">
          <div className="px-8 py-4 border-b border-border-warm flex items-center justify-between bg-slate-50/50">
            <h3 className="text-[11px] uppercase tracking-widest font-bold text-slate-500 flex items-center gap-2">
              <Upload className="w-3.5 h-3.5 text-primary" />
              Ingest Expense Node
            </h3>
            <div className="flex items-center gap-6">
              <input 
                type="file" 
                accept=".csv,.txt" 
                className="hidden" 
                ref={fileInputRef}
                onChange={handleFileUpload}
              />
              <button 
                onClick={() => fileInputRef.current?.click()}
                className="text-[11px] uppercase font-bold text-slate-600 hover:text-primary transition-colors flex items-center gap-1.5"
              >
                <FileUp className="w-3.5 h-3.5" />
                Upload CSV
              </button>
              <span className="text-[10px] uppercase font-bold text-slate-400 tracking-widest hidden md:inline">Format: Vendor, Amount, Date, Description</span>
            </div>
          </div>
          <div className="p-6">
            <textarea
              value={inputText}
              onChange={(e) => {
                setInputText(e.target.value);
                if (inputError) setInputError(null);
              }}
              placeholder="Microsoft Azure, 1200.50, 2024-05-15, Cloud hosting fees..."
              className={`w-full h-32 bg-[#FBF9F6] border ${inputError ? 'border-accent-rose/50 focus:border-accent-rose shadow-[0_0_0_4px_rgba(244,63,94,0.05)]' : 'border-border-warm focus:border-primary/50 focus:shadow-[0_0_0_4px_rgba(139,94,60,0.05)]'} rounded-2xl p-5 text-sm font-medium text-slate-700 outline-none transition-all placeholder:text-slate-400`}
            />
            {inputError && (
              <p className="text-[11px] text-accent-rose font-bold mt-3 flex items-center gap-2 bg-accent-rose/5 p-2 rounded-lg border border-accent-rose/10">
                <AlertTriangle className="w-3.5 h-3.5" />
                {inputError}
              </p>
            )}
            <div className="mt-6 flex flex-col md:flex-row justify-between items-center gap-4">
              <button
                onClick={handleGenerateInsight}
                disabled={isGeneratingInsight || expenses.length === 0}
                className="w-full md:w-auto text-[11px] font-bold text-primary border border-primary/20 px-6 py-3 rounded-xl hover:bg-primary/5 transition-all flex items-center justify-center gap-2"
              >
                {isGeneratingInsight ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>Extracting Insights...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-3.5 h-3.5" />
                    Generate AI Intelligence
                  </>
                )}
              </button>
              <button
                onClick={handleProcess}
                disabled={isProcessing || !inputText.trim()}
                className="w-full md:w-auto bg-[#D4A373] hover:bg-[#B28451] disabled:opacity-50 text-white text-[12px] font-bold uppercase tracking-widest py-3 px-8 rounded-xl transition-all flex items-center justify-center gap-2 shadow-sm"
              >
                {isProcessing ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span className="animate-pulse">AI is analyzing...</span>
                  </>
                ) : (
                  <>Process Manual Entry</>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Anomaly Feed */}
        <div className="dashboard-card overflow-hidden flex flex-col border-accent-rose/20 bg-accent-rose/[0.02]">
          <div className="px-6 py-4 border-b border-accent-rose/10 flex items-center gap-2 bg-accent-rose/5">
            <ShieldAlert className="w-3.5 h-3.5 text-accent-rose" />
            <h3 className="text-[11px] uppercase tracking-widest font-bold text-accent-rose">Integrity Log</h3>
          </div>
          <div className="p-5 flex-1 space-y-4 max-h-[300px] lg:max-h-none overflow-y-auto pr-2 scrollbar-hide">
            {anomalies.length > 0 ? (
              anomalies.map(ano => (
                <div key={ano.id} className="p-4 rounded-xl bg-white border border-accent-rose/10 shadow-sm transition-all hover:shadow-md group">
                  <div className="flex justify-between font-bold text-[#1A202C] mb-2 text-xs">
                    <span className="truncate">{ano.vendor}</span>
                    <span className="text-accent-rose flex-shrink-0 ml-2 font-extrabold">{formatCurrency(ano.amount)}</span>
                  </div>
                  <p className="text-slate-500 text-[11px] leading-relaxed italic line-clamp-2">"{ano.anomalyReason}"</p>
                </div>
              ))
            ) : (
              <div className="h-full flex flex-col items-center justify-center py-12 text-slate-300 opacity-60">
                <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center border border-border-warm mb-4 shadow-sm">
                  <CheckCircle2 className="w-6 h-6 text-accent-emerald" />
                </div>
                <p className="text-[10px] font-bold uppercase tracking-widest">System Integrity Clean</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* AI Insight Box */}
      <AnimatePresence>
        {aiInsights && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="dashboard-card border-[#F4E3D1] bg-[#FFF9F2] overflow-hidden"
          >
            <div className="px-8 py-4 border-b border-[#F4E3D1] flex justify-between items-center bg-[#FDF2E6]/50">
              <div className="flex items-center gap-3">
                <div className="p-1.5 bg-[#F4E3D1] rounded-lg">
                  <Sparkles className="w-4 h-4 text-[#8B5E3C] animate-pulse" />
                </div>
                <h3 className="text-[12px] font-extrabold text-[#8B5E3C] uppercase tracking-widest">Executive AI Intelligence Summary</h3>
              </div>
              <button onClick={() => setAiInsights(null)} className="text-slate-400 hover:text-slate-600 p-1">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-8 grid grid-cols-1 md:grid-cols-5 gap-8">
              {aiInsights.map((insight, i) => (
                <div key={i} className="flex gap-4 text-xs leading-relaxed text-slate-700">
                  <span className="text-[#D4A373] font-black text-sm">✦</span>
                  <p className="font-medium">{insight}</p>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Visuals Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="dashboard-card overflow-hidden">
          <div className="px-8 py-5 border-b border-border-warm flex items-center justify-between">
            <h3 className="text-[11px] font-extrabold text-slate-500 flex items-center gap-2 uppercase tracking-widest">
              <PieChart className="w-3.5 h-3.5 text-primary" />
              Taxonomy Breakdown
            </h3>
          </div>
          <div className="p-8 h-80">
            <ResponsiveContainer width="100%" height="100%">
              <RechartsPie>
                <Pie
                  data={costTypeData}
                  innerRadius={70}
                  outerRadius={95}
                  paddingAngle={6}
                  dataKey="value"
                  stroke="none"
                >
                  {costTypeData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ backgroundColor: '#fff', border: 'none', borderRadius: '16px', fontSize: '11px', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)' }}
                  formatter={(value: any, name: any) => [`$${value.toLocaleString()}`, `${name}`]}
                />
              </RechartsPie>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="dashboard-card overflow-hidden">
          <div className="px-8 py-5 border-b border-border-warm flex items-center justify-between">
            <h3 className="text-[11px] font-extrabold text-slate-500 flex items-center gap-2 uppercase tracking-widest">
              <Activity className="w-3.5 h-3.5 text-accent-emerald" />
              Expenditure Vectors
            </h3>
          </div>
          <div className="p-8 h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={costCenterData} margin={{ top: 20, right: 30, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#EDF2F7" />
                <XAxis dataKey="name" stroke="#A0AEC0" fontSize={10} axisLine={false} tickLine={false} tick={{ fontWeight: 600 }} dy={10} />
                <YAxis stroke="#A0AEC0" fontSize={10} axisLine={false} tickLine={false} tickFormatter={(val) => `$${val/1000}k`} />
                <Tooltip 
                  cursor={{ fill: '#F7FAFC' }}
                  contentStyle={{ backgroundColor: '#fff', border: 'none', borderRadius: '16px', fontSize: '11px', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)' }}
                  formatter={(value: any) => [`$${value.toLocaleString()}`, 'Amount']}
                />
                <Bar dataKey="value" fill="#D4A373" radius={[6, 6, 0, 0]} barSize={40} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Table Section */}
      <div className="dashboard-card overflow-hidden">
        <div className="px-8 py-6 flex justify-between items-center bg-slate-50/50 border-b border-border-warm">
          <h3 className="text-[12px] font-extrabold text-[#1A202C] uppercase tracking-widest">Recent Classifications</h3>
          <div className="flex gap-2">
            <div className="h-1.5 w-1.5 rounded-full bg-primary opacity-30"></div>
            <div className="h-1.5 w-1.5 rounded-full bg-primary opacity-30"></div>
            <div className="h-1.5 w-1.5 rounded-full bg-primary"></div>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="text-[11px] font-extrabold text-slate-400 uppercase tracking-widest border-b border-border-warm">
                <th className="px-8 py-4">Vendor / Description</th>
                <th className="px-8 py-4">Type</th>
                <th className="px-8 py-4">Center</th>
                <th className="px-8 py-4 text-right">Amount</th>
                <th className="px-8 py-4 text-center">Score</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border-warm text-sm">
              <AnimatePresence initial={false}>
                {filteredExpenses.map((expense) => (
                  <motion.tr
                    key={expense.id}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className={`hover:bg-slate-50/50 transition-colors group ${expense.isAnomaly ? 'bg-accent-rose/[0.02]' : ''}`}
                  >
                    <td className="px-8 py-5">
                      <div className="flex flex-col">
                        <span className={`font-bold text-slate-900 ${expense.isAnomaly ? 'text-accent-rose underline decoration-accent-rose/30' : ''}`}>
                          {expense.vendor}
                        </span>
                        <span className="text-[11px] text-slate-400 font-medium truncate max-w-[240px] mt-0.5">{expense.description}</span>
                      </div>
                    </td>
                    <td className="px-8 py-5">
                      <span className={`px-2.5 py-1 rounded-lg text-[10px] font-extrabold uppercase tracking-tight ${
                        expense.costType === CostType.DIRECT ? 'bg-accent-emerald/10 text-accent-emerald' : 'bg-primary/10 text-primary'
                      }`}>
                        {expense.costBehavior === CostBehavior.VARIABLE ? 'Variable' : expense.costBehavior}
                      </span>
                    </td>
                    <td className="px-8 py-5 text-slate-500 font-medium text-xs">
                      {expense.costCenter || '—'}
                    </td>
                    <td className={`px-8 py-5 font-black text-right ${expense.isAnomaly ? 'text-accent-rose' : 'text-slate-900'}`}>
                      {formatCurrency(expense.amount)}
                    </td>
                    <td className="px-8 py-5 text-center">
                      <span className={`px-2.5 py-1 rounded-lg text-[10px] font-black border ${
                        (expense.confidence || 0) > 0.9 ? 'text-accent-emerald bg-accent-emerald/5 border-accent-emerald/10' : 'text-primary bg-primary/5 border-primary/10'
                      }`}>
                        {expense.confidence?.toFixed(2)}
                      </span>
                    </td>
                  </motion.tr>
                ))}
              </AnimatePresence>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
