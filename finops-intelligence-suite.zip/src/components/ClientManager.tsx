import { useState } from 'react';
import { 
  Users, Search, Filter, Plus, MoreVertical, 
  Mail, Phone, Globe, MapPin, 
  ChevronRight, ArrowUpRight, DollarSign,
  Briefcase, Calendar, Star, ShieldCheck
} from 'lucide-react';
import { useFinancial } from '../context/FinancialContext';

interface Client {
  id: string;
  name: string;
  company: string;
  email: string;
  status: 'Active' | 'Onboarding' | 'Idle';
  value: number;
  lastContact: string;
  type: string;
}

export function ClientManager() {
  const { formatCurrency, expenses, searchQuery } = useFinancial();
  
  // Create a dynamic client list based on vendors in expenses + base clients
  const baseClients = [
    { id: '1', name: 'Alina Shakes', company: 'Nexus Digital', email: 'alina@nexus.io', status: 'Active', value: 85000, lastContact: '2 hours ago', type: 'Enterprise' },
    { id: '2', name: 'Zayn Malik', company: 'Vogue Dynamics', email: 'zayn@vogue.co', status: 'Active', value: 124000, lastContact: '1 day ago', type: 'Subscription' },
    { id: '3', name: 'Rayan Gosling', company: 'Drive Automations', email: 'ryan@drive.com', status: 'Onboarding', value: 45000, lastContact: '3 days ago', type: 'Project-based' },
  ];

  // Map expenses to clients to update their value
  const clientList = baseClients.map(client => {
    const clientSpend = expenses
      .filter(e => e.vendor.toLowerCase().includes(client.company.toLowerCase()) || e.vendor.toLowerCase().includes(client.name.toLowerCase()))
      .reduce((sum, e) => sum + e.amount, 0);
    return { ...client, value: client.value + clientSpend };
  });

  const filteredClients = clientList.filter(c => 
    c.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    c.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.type.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Active': return 'bg-emerald-50 text-emerald-600 border-emerald-100';
      case 'Onboarding': return 'bg-blue-50 text-blue-600 border-blue-100';
      case 'Idle': return 'bg-amber-50 text-amber-600 border-amber-100';
      default: return 'bg-slate-50 text-slate-600 border-slate-100';
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* Header Actions */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h2 className="text-2xl font-extrabold text-[#1A202C] tracking-tight">Client Ecosystem</h2>
          <p className="text-sm font-medium text-slate-500 mt-1">Manage your professional relationships and lifecycle value.</p>
        </div>
        <div className="flex items-center gap-3">
          <button className="p-2.5 border border-border-warm rounded-xl hover:bg-slate-50 text-slate-500 transition-colors">
            <Filter className="w-5 h-5" />
          </button>
          <button className="bg-primary hover:bg-[#B28451] text-white px-5 py-2.5 rounded-xl font-bold text-sm flex items-center gap-2 shadow-md shadow-primary/20 transition-all">
            <Plus className="w-4 h-4" />
            New Client
          </button>
        </div>
      </div>

      {/* Stats overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {[
          { label: 'Total Clients', value: '142', sub: '+12 this month', icon: Users, color: 'text-primary bg-primary/10' },
          { label: 'Active Revenue', value: formatCurrency(12400000), sub: 'Projected Q2', icon: DollarSign, color: 'text-emerald-600 bg-emerald-50' },
          { label: 'Retention Rate', value: '98.5%', sub: 'Last 12 months', icon: Star, color: 'text-amber-600 bg-amber-50' },
          { label: 'Risk Accounts', value: '3', sub: 'Action required', icon: ShieldCheck, color: 'text-rose-600 bg-rose-50' },
        ].map((stat, i) => (
          <div key={i} className="dashboard-card p-6">
            <div className={`w-10 h-10 rounded-lg flex items-center justify-center mb-4 ${stat.color}`}>
              <stat.icon className="w-5 h-5" />
            </div>
            <p className="text-[10px] font-extrabold text-slate-400 uppercase tracking-[0.2em]">{stat.label}</p>
            <h3 className="text-2xl font-extrabold text-[#1A202C] mt-1">{stat.value}</h3>
            <p className="text-[10px] font-bold text-slate-500 mt-2 flex items-center gap-1">
              <span className="text-emerald-500">✦</span> {stat.sub}
            </p>
          </div>
        ))}
      </div>

      {/* Client List */}
      <div className="dashboard-card overflow-hidden">
        <div className="px-8 py-5 border-b border-border-warm bg-slate-50/50 flex items-center justify-between">
          <h3 className="text-xs font-extrabold text-slate-500 uppercase tracking-[0.2em]">Active Portfolios</h3>
          <span className="text-[10px] font-bold text-primary bg-primary/5 px-2 py-1 rounded-md border border-primary/10 tracking-widest uppercase">Sort: Value High-Low</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-white">
                <th className="px-8 py-4 text-[10px] font-extrabold text-slate-400 uppercase tracking-widest">Client & Entity</th>
                <th className="px-8 py-4 text-[10px] font-extrabold text-slate-400 uppercase tracking-widest">Status</th>
                <th className="px-8 py-4 text-[10px] font-extrabold text-slate-400 uppercase tracking-widest">Type</th>
                <th className="px-8 py-4 text-[10px] font-extrabold text-slate-400 uppercase tracking-widest text-right">LTV</th>
                <th className="px-8 py-4 text-[10px] font-extrabold text-slate-400 uppercase tracking-widest">Last Sync</th>
                <th className="px-8 py-4 w-10"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border-warm">
              {filteredClients.map((client) => (
                <tr key={client.id} className="hover:bg-slate-50/50 transition-colors group cursor-pointer">
                  <td className="px-8 py-5">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center font-bold text-slate-400 border border-border-warm text-sm">
                        {client.name.charAt(0)}
                      </div>
                      <div>
                        <p className="text-sm font-bold text-slate-900 leading-tight">{client.name}</p>
                        <p className="text-[11px] text-slate-500 font-medium mt-0.5">{client.company}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-8 py-5">
                    <span className={`px-2.5 py-1 rounded-lg text-[10px] font-black uppercase tracking-widest border ${getStatusColor(client.status)}`}>
                      {client.status}
                    </span>
                  </td>
                  <td className="px-8 py-5">
                    <div className="flex items-center gap-2">
                      <Briefcase className="w-3.5 h-3.5 text-slate-400" />
                      <span className="text-[11px] font-bold text-slate-600">{client.type}</span>
                    </div>
                  </td>
                  <td className="px-8 py-5 text-right font-extrabold text-sm text-slate-900 tracking-tight">
                    {formatCurrency(client.value)}
                  </td>
                  <td className="px-8 py-5">
                    <div className="flex items-center gap-2 text-[11px] text-slate-500 font-medium">
                      <Calendar className="w-3.5 h-3.5" />
                      {client.lastContact}
                    </div>
                  </td>
                  <td className="px-8 py-5">
                    <button className="p-2 text-slate-300 hover:text-slate-600 transition-colors">
                      <MoreVertical className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Empty State / Footer */}
      {filteredClients.length === 0 && (
        <div className="text-center py-20 bg-white border border-border-warm rounded-[24px]">
          <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-6">
            <Users className="w-8 h-8 text-slate-300" />
          </div>
          <h3 className="text-lg font-extrabold text-[#1A202C] mb-2 tracking-tight">No clients found</h3>
          <p className="text-sm text-slate-500 max-w-xs mx-auto mb-8 font-medium">We couldn't find any clients matching your search criteria.</p>
        </div>
      )}
    </div>
  );
}
