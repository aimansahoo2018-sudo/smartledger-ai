import { motion, AnimatePresence } from 'motion/react';
import { Bot, X, Sparkles, Send, Loader2 } from 'lucide-react';
import { useState, useRef, useEffect } from 'react';
import { useFinancial } from '../context/FinancialContext';
import { chatWithFinanceAI } from '../services/geminiService';
import Markdown from 'react-markdown';

interface ChatMessage {
  role: 'user' | 'model';
  content: string;
}

export function FloatingAiButton() {
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      role: 'model',
      content: "System ready. I've analyzed your financial velocity. Ask me anything about your revenue, expenses, or runway."
    }
  ]);
  
  const { setActiveTab, totals, expenses, timeframe } = useFinancial();
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const handleSend = async () => {
    if (!input.trim() || isTyping) return;

    const userMessage: ChatMessage = {
      role: 'user',
      content: input
    };

    setMessages(prev => [...prev, userMessage]);
    const currentInput = input;
    setInput('');
    setIsTyping(true);

    try {
      // Map to service history format
      const history = messages.map(msg => ({
        role: msg.role,
        parts: msg.content
      }));
      history.push({ role: 'user', parts: currentInput });

      // Build context string
      const financialContext = `
        Current Financial State:
        - Revenue: ${totals.revenue}
        - Total Expenses: ${totals.expenses}
        - Pending Invoices: ${totals.pendingInvoices}
        - Tax Estimate: ${totals.taxEstimate}
        - Timeframe: ${timeframe}
        - Recent Expenses: ${expenses.slice(0, 5).map(e => `${e.vendor}: ${e.amount}`).join(', ')}
      `;

      const response = await chatWithFinanceAI(history, financialContext);
      
      const aiMessage: ChatMessage = {
        role: 'model',
        content: response || "I'm sorry, I couldn't process that request."
      };
      setMessages(prev => [...prev, aiMessage]);
    } catch (error) {
      console.error("AI Error:", error);
      setMessages(prev => [...prev, {
        role: 'model',
        content: "Core synchronization failed. Please try again."
      }]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="fixed bottom-8 right-8 z-[100] flex flex-col items-end gap-4">
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 20 }}
            className="w-80 h-[520px] bg-slate-900 rounded-[32px] shadow-2xl border border-white/10 flex flex-col overflow-hidden mb-4"
          >
            {/* Header */}
            <div className="p-6 bg-white/5 border-b border-white/5 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-emerald-400/10 rounded-xl border border-emerald-400/20">
                   <Sparkles className="w-4 h-4 text-emerald-400 fill-emerald-400/20" />
                </div>
                <div>
                   <h3 className="font-black text-white text-sm tracking-tight">Signal Assistant</h3>
                   <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest leading-none mt-1">Enterprise Core Link</p>
                </div>
              </div>
              <button 
                onClick={() => setIsOpen(false)}
                className="text-slate-400 hover:text-white transition-colors p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Chat Content */}
            <div 
              ref={scrollRef}
              className="flex-1 p-6 overflow-y-auto space-y-4 scrollbar-hide"
            >
               {messages.map((msg, i) => (
                 <div 
                    key={i} 
                    className={`${
                      msg.role === 'user' 
                        ? 'bg-emerald-400 text-slate-900 ml-auto rounded-tr-none' 
                        : 'bg-white/5 text-slate-300 mr-auto rounded-tl-none border border-white/5'
                    } p-4 rounded-2xl max-w-[90%] shadow-lg`}
                 >
                    <div className="markdown-body prose prose-invert prose-sm">
                        <Markdown>{msg.content}</Markdown>
                    </div>
                 </div>
               ))}
               {isTyping && (
                 <div className="bg-white/5 p-4 rounded-2xl rounded-tl-none border border-white/5 max-w-[90%] flex items-center gap-2">
                    <Loader2 className="w-3 h-3 text-emerald-400 animate-spin" />
                    <span className="text-[10px] text-slate-500 font-black uppercase tracking-widest animate-pulse">Analyzing...</span>
                 </div>
               )}
            </div>

            {/* Input */}
            <div className="p-4 bg-white/5 border-t border-white/5">
               <div className="relative">
                  <input 
                    type="text" 
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                    placeholder="Ask signal anything..." 
                    className="w-full bg-slate-800 border border-white/5 rounded-2xl py-3 px-4 text-white text-xs placeholder:text-slate-500 outline-none focus:ring-2 focus:ring-emerald-400/50 transition-all font-semibold"
                  />
                  <div className="absolute right-2 top-1.5">
                     <button 
                        onClick={handleSend}
                        disabled={!input.trim() || isTyping}
                        className="p-1.5 bg-emerald-400 text-slate-900 rounded-xl hover:scale-110 active:scale-95 transition-all disabled:opacity-50"
                     >
                        <Send className="w-3 h-3" />
                     </button>
                  </div>
               </div>
            </div>
            
            <button 
              onClick={() => {
                setActiveTab('ai-assistant');
                setIsOpen(false);
              }}
              className="w-full py-3 bg-white/5 text-slate-400 text-[10px] font-black uppercase tracking-[0.2em] hover:text-white transition-colors hover:bg-white/10"
            >
              Expand to Workspace
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setIsOpen(!isOpen)}
        className="w-16 h-16 bg-slate-900 text-emerald-400 rounded-full flex items-center justify-center shadow-2xl border border-white/10 relative group ring-4 ring-emerald-400/10"
      >
        <div className="absolute inset-0 bg-emerald-400 opacity-20 blur-xl group-hover:opacity-40 transition-opacity animate-pulse" />
        {isOpen ? <X className="w-6 h-6 relative z-10" /> : <Bot className="w-6 h-6 relative z-10" />}
        {!isOpen && (
          <div className="absolute -top-1 -right-1 w-5 h-5 bg-emerald-400 text-slate-900 rounded-full flex items-center justify-center text-[10px] font-black shadow-lg">
             !
          </div>
        )}
      </motion.button>
    </div>
  );
}

