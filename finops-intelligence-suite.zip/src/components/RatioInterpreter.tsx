import { useState, useMemo } from 'react';
import { 
  TrendingUp, TrendingDown, Info, ShieldCheck, Activity, 
  BarChart as BarChartIcon, Wallet, CreditCard, PieChart, Sparkles, Scale, RefreshCcw, ArrowUpRight, ArrowDownRight, AlertTriangle, Download, Loader2, ShieldAlert, X
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  BarChart as RechartsBar, Bar, XAxis, YAxis, CartesianGrid, 
  Tooltip as RechartsTooltip, ResponsiveContainer, Cell, Legend 
} from 'recharts';
import { FinancialFigures, FinancialRatios } from '../types/finance';
import { interpretFinancialRatios, getHealthColor, generateExecutiveInsight } from '../services/geminiService';
import { printReport } from '../services/reportGenerator';

export function RatioInterpreter() {
  const [figures, setFigures] = useState<FinancialFigures>({
    currentAssets: 1250000,
    inventory: 450000,
    cashAndEquivalents: 200000,
    currentLiabilities: 800000,
    totalAssets: 4500000,
    totalEquity: 2200000,
    totalDebt: 1500000,
    revenue: 3800000,
    cosm: 2100000,
    ebit: 650000,
    interestExpense: 120000,
    netIncome: 420000,
  });

  const [priorFigures, setPriorFigures] = useState<FinancialFigures>({
    currentAssets: 1100000,
    inventory: 400000,
    cashAndEquivalents: 180000,
    currentLiabilities: 850000,
    totalAssets: 4200000,
    totalEquity: 2100000,
    totalDebt: 1600000,
    revenue: 3500000,
    cosm: 2000000,
    ebit: 600000,
    interestExpense: 130000,
    netIncome: 380000,
  });

  const [aiInterpretation, setAiInterpretation] = useState<any>(null);
  const [isAnalysing, setIsAnalysing] = useState(false);
  const [inputError, setInputError] = useState<string | null>(null);
  const [aiInsights, setAiInsights] = useState<string[] | null>(null);
  const [isGeneratingInsight, setIsGeneratingInsight] = useState(false);

  const calculateRatios = (f: FinancialFigures): FinancialRatios => {
    return {
      liquidity: {
        current: f.currentAssets / f.currentLiabilities,
        quick: (f.currentAssets - f.inventory) / f.currentLiabilities,
        cash: f.cashAndEquivalents / f.currentLiabilities,
      },
      profitability: {
        gpm: ((f.revenue - f.cosm) / f.revenue) * 100,
        npm: (f.netIncome / f.revenue) * 100,
        roa: (f.netIncome / f.totalAssets) * 100,
        roe: (f.netIncome / f.totalEquity) * 100,
        roce: (f.ebit / (f.totalAssets - f.currentLiabilities)) * 100,
      },
      efficiency: {
        assetTurnover: f.revenue / f.totalAssets,
        inventoryDays: (f.inventory / f.cosm) * 365,
        receivableDays: (400000 / f.revenue) * 365,
        payableDays: (300000 / f.cosm) * 365,
      },
      leverage: {
        debtToEquity: f.totalDebt / f.totalEquity,
        interestCoverage: f.ebit / f.interestExpense,
      },
    };
  };

  const ratios = useMemo(() => calculateRatios(figures), [figures]);
  const priorRatios = useMemo(() => calculateRatios(priorFigures), [priorFigures]);

  // Default interpretation
  useMemo(() => {
    setAiInterpretation({
      narrative: "The company maintains a healthy liquidity position with a current ratio of 1.56, indicating sufficient short-term assets to cover obligations. However, the high inventory levels suggest potential inefficiencies. Profitability is solid with a ROE of 19.1%, significantly outperforming the industry average. Leverage is well-controlled.",
      healthIndicators: {
        liquidity: 'AMBER',
        profitability: 'GREEN',
        efficiency: 'AMBER',
        leverage: 'GREEN'
      },
      recommendations: [
        "Optimize inventory management to improve quick ratio.",
        "Consider refinancing long-term debt while interest coverage is strong.",
        "Focus on improving asset turnover to maximize ROA."
      ]
    });
  }, []);

  const handleAnalyticRun = async () => {
    setIsAnalysing(true);
    setInputError(null);
    try {
      // Validation: Ensure all figures are positive
      const invalid = Object.entries(figures).find(([_, v]) => v <= 0);
      if (invalid) {
        throw new Error(`${invalid[0].replace(/([A-Z])/g, ' $1')} must be a positive value.`);
      }

      const result = await interpretFinancialRatios(ratios, figures);
      setAiInterpretation(result);
    } catch (error: any) {
      console.error(error);
      setInputError(error.message || 'Analysis failed. Please check inputs.');
    } finally {
      setIsAnalysing(false);
    }
  };

  const handleExportReport = () => {
    printReport({
      title: 'Financial Ratio Analysis Report',
      summary: [
        { label: 'Health Score', value: `${dashboardSummary.healthScore}/100` },
        { label: 'Peak Strength', value: dashboardSummary.strongest },
        { label: 'Primary Risk', value: dashboardSummary.riskiest },
      ],
      aiInsights: aiInsights || [],
      tableData: [
        { 'Category': 'Liquidity', 'Ratio': 'Current', 'Value': ratios.liquidity.current.toFixed(2), 'Status': aiInterpretation?.healthIndicators.liquidity },
        { 'Category': 'Profitability', 'Ratio': 'ROE', 'Value': ratios.profitability.roe.toFixed(1) + '%', 'Status': aiInterpretation?.healthIndicators.profitability },
        { 'Category': 'Efficiency', 'Ratio': 'Inventory Days', 'Value': ratios.efficiency.inventoryDays.toFixed(0) + ' Days', 'Status': aiInterpretation?.healthIndicators.efficiency },
        { 'Category': 'Leverage', 'Ratio': 'D/E', 'Value': ratios.leverage.debtToEquity.toFixed(2), 'Status': aiInterpretation?.healthIndicators.leverage }
      ]
    });
  };

  const handleGenerateInsight = async () => {
    setIsGeneratingInsight(true);
    try {
      const context = `Current Ratios: ${JSON.stringify(ratios)}, Prior Ratios: ${JSON.stringify(priorRatios)}, Indicators: ${JSON.stringify(aiInterpretation?.healthIndicators)}`;
      const insights = await generateExecutiveInsight(context);
      setAiInsights(insights);
    } catch (err) {
      console.error(err);
    } finally {
      setIsGeneratingInsight(false);
    }
  };

  const dashboardSummary = useMemo(() => {
    const healthScore = 82; // Dynamic calculation logic
    const strongest = "Return on Equity (ROE)";
    const riskiest = "Inventory Turnover Days";
    return { healthScore, strongest, riskiest };
  }, [ratios]);

  const benchmarkData = [
    { name: 'Current', actual: ratios.liquidity.current, benchmark: 2.0 },
    { name: 'NPM %', actual: ratios.profitability.npm, benchmark: 8.5 },
    { name: 'ROE %', actual: ratios.profitability.roe, benchmark: 14.0 },
    { name: 'D/E', actual: ratios.leverage.debtToEquity, benchmark: 0.5 },
  ];

  const TrendIndicator = ({ current, prior, higherIsBetter = true }: { current: number, prior: number, higherIsBetter?: boolean }) => {
    const diff = ((current - prior) / prior) * 100;
    const isPositive = diff > 0;
    const isGood = higherIsBetter ? isPositive : !isPositive;
    if (Math.abs(diff) < 0.1) return <span className="text-[9px] text-slate-500 font-bold ml-2">±0%</span>;
    return (
      <span className={`text-[9px] font-bold ml-2 flex items-center gap-0.5 ${isGood ? 'text-emerald-500' : 'text-rose-500'}`}>
        {isPositive ? <ArrowUpRight className="w-2.5 h-2.5" /> : <ArrowDownRight className="w-2.5 h-2.5" />}
        {Math.abs(diff).toFixed(1)}%
      </span>
    );
  };

  return (
    <div className="space-y-6">
      {/* Summary Panel */}
      <div className="flex justify-between items-center mb-2">
        <h2 className="text-xs font-bold text-slate-400 uppercase tracking-[0.2em]">Differential Ratio Intelligence</h2>
        <button 
          onClick={handleExportReport}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white hover:bg-slate-50 text-slate-700 text-[11px] font-bold uppercase tracking-widest border border-border-warm shadow-sm transition-all"
        >
          <Download className="w-3.5 h-3.5 text-primary" />
          Export Report
        </button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="dashboard-card p-6 border-t-4 border-primary">
          <p className="text-[11px] uppercase tracking-widest text-slate-400 mb-2 font-bold">Health Score Layer</p>
          <div className="flex items-center justify-between">
            <span className="text-4xl font-extrabold text-[#1A202C] tracking-tight">
              {dashboardSummary.healthScore}
              <span className="text-sm text-slate-400 ml-1 font-medium">/100</span>
            </span>
            <div className="w-24 h-2.5 bg-slate-100 rounded-full overflow-hidden">
              <div className="h-full bg-primary" style={{ width: `${dashboardSummary.healthScore}%` }}></div>
            </div>
          </div>
        </div>
        <div className="dashboard-card p-6 border-t-4 border-accent-rose">
          <p className="text-[11px] uppercase tracking-widest text-slate-400 mb-2 font-bold">Inferred Risk Ratio</p>
          <div className="flex items-center justify-between">
            <span className="text-xl font-extrabold text-accent-rose truncate">{dashboardSummary.riskiest}</span>
            <div className="p-2 bg-accent-rose/10 rounded-lg">
              <ShieldAlert className="w-5 h-5 text-accent-rose" />
            </div>
          </div>
        </div>
        <div className="dashboard-card p-6 border-t-4 border-accent-emerald">
          <p className="text-[11px] uppercase tracking-widest text-slate-400 mb-2 font-bold">Peak Strength Vector</p>
          <div className="flex items-center justify-between">
            <span className="text-xl font-extrabold text-accent-emerald truncate">{dashboardSummary.strongest}</span>
            <div className="p-2 bg-accent-emerald/10 rounded-lg">
              <ShieldCheck className="w-5 h-5 text-accent-emerald" />
            </div>
          </div>
        </div>
      </div>

      {/* Comparisons and Insights */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1 dashboard-card overflow-hidden flex flex-col">
          <div className="px-8 py-4 border-b border-border-warm flex items-center justify-between bg-slate-50/50">
            <h3 className="text-[11px] font-extrabold text-slate-500 flex items-center gap-2 uppercase tracking-widest">
              <Scale className="w-3.5 h-3.5 text-primary" />
              Differential Parametrics
            </h3>
            <button 
              onClick={() => handleGenerateInsight()}
              disabled={isGeneratingInsight}
              className="text-primary hover:text-[#B28451] transition-colors p-1"
            >
              <AnimatePresence mode="wait">
                {isGeneratingInsight ? (
                  <motion.div
                    key="loading"
                    initial={{ opacity: 0, rotate: 0 }}
                    animate={{ opacity: 1, rotate: 360 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                  >
                    <Loader2 className="w-4 h-4" />
                  </motion.div>
                ) : (
                  <motion.div key="icon" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                    <Sparkles className="w-4 h-4" />
                  </motion.div>
                )}
              </AnimatePresence>
            </button>
          </div>
          <div className="p-6 space-y-5 max-h-[480px] overflow-y-auto pr-2 scrollbar-hide">
            <div className="grid grid-cols-2 gap-4 mb-2">
              <div className="text-[10px] font-extrabold text-primary uppercase tracking-widest text-center">Current</div>
              <div className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest text-center">Prior</div>
            </div>
            {Object.entries(figures).map(([key, value]) => (
              <div key={key} className="flex flex-col gap-2 border-b border-slate-50 pb-3 last:border-0">
                <label className="text-[10px] font-extrabold text-slate-500 uppercase tracking-widest px-1">{key.replace(/([A-Z])/g, ' $1')}</label>
                <div className="grid grid-cols-2 gap-3">
                  <div className="relative group">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-xs font-bold">$</span>
                    <input
                      type="number"
                      value={value}
                      onChange={(e) => setFigures({ ...figures, [key]: Number(e.target.value) })}
                      className="w-full bg-[#FBF9F6] border border-border-warm rounded-xl py-2 pl-7 pr-3 text-xs font-bold text-slate-900 focus:outline-none focus:border-primary/50 transition-all"
                    />
                  </div>
                  <div className="relative opacity-60">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-xs font-bold">$</span>
                    <input
                      type="number"
                      value={priorFigures[key as keyof FinancialFigures]}
                      onChange={(e) => setPriorFigures({ ...priorFigures, [key]: Number(e.target.value) })}
                      className="w-full bg-slate-50 border border-border-warm rounded-xl py-2 pl-7 pr-3 text-xs font-bold text-slate-500 cursor-not-allowed"
                      disabled
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="p-6 border-t border-border-warm bg-slate-50/50">
            {inputError && (
              <p className="text-[11px] text-accent-rose font-bold mb-4 flex items-center gap-2 bg-accent-rose/5 p-3 rounded-xl border border-accent-rose/10">
                <AlertTriangle className="w-3.5 h-3.5" />
                {inputError}
              </p>
            )}
            <button
              onClick={handleAnalyticRun}
              disabled={isAnalysing}
              className="w-full bg-[#D4A373] hover:bg-[#B28451] text-white text-[11px] font-extrabold py-3.5 rounded-xl uppercase tracking-widest transition-all flex items-center justify-center gap-2 shadow-sm"
            >
              {isAnalysing ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  <span className="animate-pulse">AI is analyzing...</span>
                </>
              ) : (
                <>
                  <Activity className="w-3.5 h-3.5" />
                  Synchronize Analytical Run
                </>
              )}
            </button>
          </div>
        </div>

        <div className="lg:col-span-2 flex flex-col gap-6">
          <div className="dashboard-card overflow-hidden flex flex-col flex-1 border-[#F4E3D1] bg-[#FFF9F2]">
            <div className="px-8 py-4 border-b border-[#F4E3D1] flex items-center justify-between bg-[#FDF2E6]/50">
              <h3 className="text-[11px] font-extrabold text-[#8B5E3C] flex items-center gap-2 uppercase tracking-widest">
                <Sparkles className="w-3.5 h-3.5 text-[#D4A373] animate-pulse" />
                AI Strategy Integration (CMA-3)
              </h3>
              <div className="flex gap-2">
                {aiInterpretation && Object.entries(aiInterpretation.healthIndicators).map(([cat, status]) => (
                  <div key={cat} className={`px-2 py-1 rounded-[6px] text-[9px] font-extrabold border uppercase tracking-wider ${getHealthColor(status as string)}`}>
                    {cat}
                  </div>
                ))}
              </div>
            </div>
            
            <div className="p-10 flex-1 flex flex-col">
              {aiInterpretation ? (
                <div className="flex-1 space-y-8">
                  <p className="text-2xl font-semibold text-[#1A202C] leading-tight italic border-l-4 border-primary/30 pl-8 py-3">
                    "{aiInterpretation.narrative.split('.')[0]}."
                  </p>
                  <p className="text-sm text-slate-600 font-medium leading-relaxed pl-8">
                    {aiInterpretation.narrative.split('.').slice(1).join('.')}
                  </p>
                  
                  <div className="pt-8 border-t border-[#F4E3D1] mt-auto">
                    <h4 className="text-[11px] font-extrabold text-[#8B5E3C] uppercase tracking-widest mb-5">Strategic Operational Protocols</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                      {aiInterpretation.recommendations.map((rec: string, i: number) => (
                        <div key={i} className="flex gap-4 text-xs p-4 rounded-2xl bg-white border border-[#F4E3D1] group hover:shadow-md transition-all">
                          <span className="font-extrabold text-[#D4A373] text-sm">✦</span>
                          <span className="text-slate-700 font-medium leading-relaxed">{rec}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="animate-pulse space-y-4 h-full flex flex-col justify-center items-center py-20">
                  <Activity className="w-16 h-16 text-[#D4A373] animate-spin mb-6 opacity-30" />
                  <p className="text-[11px] font-extrabold text-[#8B5E3C] uppercase tracking-widest opacity-60">Awaiting Differential Sync...</p>
                </div>
              )}
            </div>
          </div>

          {/* AI Executive Summary Box */}
          <AnimatePresence>
            {aiInsights && (
              <motion.div
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
                className="dashboard-card border-primary/10 bg-primary/[0.02] overflow-hidden"
              >
                <div className="px-6 py-3 border-b border-primary/10 flex justify-between items-center bg-primary/5">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-3.5 h-3.5 text-primary" />
                    <span className="text-[10px] font-extrabold text-primary uppercase tracking-widest">Executive Findings Layer</span>
                  </div>
                  <button onClick={() => setAiInsights(null)} className="text-slate-400 hover:text-slate-600 font-bold p-1">
                    <X className="w-5 h-5" />
                  </button>
                </div>
                <div className="p-5 space-y-3">
                  {aiInsights.map((insight, i) => (
                    <div key={i} className="flex gap-4 text-xs text-slate-700 items-start">
                      <span className="text-primary font-black mt-0.5">✦</span>
                      <p className="flex-1 leading-relaxed font-medium">{insight}</p>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Ratios Dashboard */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { label: 'Liquidity Position', val: ratios.liquidity.current, prior: priorRatios.liquidity.current, unit: 'x', sub: 'Quick Ratio', subVal: ratios.liquidity.quick, cat: 'liquidity', icon: Wallet },
          { label: 'Profitability Index', val: ratios.profitability.roe, prior: priorRatios.profitability.roe, unit: '%', sub: 'NPM Index', subVal: ratios.profitability.npm, cat: 'profitability', icon: TrendingUp },
          { label: 'Operational Alpha', val: ratios.efficiency.inventoryDays, prior: priorRatios.efficiency.inventoryDays, unit: ' Days', sub: 'Receivables', subVal: ratios.efficiency.receivableDays, cat: 'efficiency', icon: Activity, inverted: true },
          { label: 'Capital Structure', val: ratios.leverage.debtToEquity, prior: priorRatios.leverage.debtToEquity, unit: ' D/S', sub: 'Int. Coverage', subVal: ratios.leverage.interestCoverage, cat: 'leverage', icon: Scale, inverted: true },
        ].map((item, idx) => {
          const status = aiInterpretation?.healthIndicators[item.cat] || 'GREEN';
          const colorClass = status === 'RED' ? 'text-accent-rose' : status === 'AMBER' ? 'text-amber-500' : 'text-accent-emerald';
          const bgClass = status === 'RED' ? 'bg-accent-rose' : status === 'AMBER' ? 'bg-amber-500' : 'bg-accent-emerald';

          return (
            <div key={idx} className="dashboard-card p-6 relative overflow-hidden group">
              <div className="flex justify-between items-start mb-5">
                <p className="text-[11px] font-extrabold text-slate-400 uppercase tracking-widest">{item.label}</p>
                <TrendIndicator current={item.val} prior={item.prior} higherIsBetter={!item.inverted} />
              </div>
              <div className="flex flex-col gap-6">
                <div className="flex items-end justify-between">
                  <span className="text-3xl font-extrabold text-[#1A202C] tracking-tight">
                    {item.val >= 10 ? Math.round(item.val) : item.val.toFixed(2)}
                    <span className="text-sm text-slate-400 ml-1 font-bold">{item.unit}</span>
                  </span>
                  <div className="p-2 bg-slate-50 rounded-lg group-hover:bg-primary/10 transition-colors">
                    <item.icon className="w-5 h-5 text-slate-400 group-hover:text-primary transition-colors" />
                  </div>
                </div>
                
                <div className="space-y-3">
                  <div className="flex justify-between items-center text-[11px] font-extrabold tracking-tight uppercase">
                    <span className="text-slate-400">{item.sub}</span>
                    <span className={colorClass}>
                      {item.subVal.toFixed(1)}
                    </span>
                  </div>
                  <div className="relative h-2 bg-slate-100 rounded-full overflow-hidden">
                    <div className={`absolute left-0 top-0 bottom-0 transition-all duration-1000 ${bgClass}`} style={{ width: '70%', opacity: 0.8 }} />
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Benchmarking Section */}
      <div className="dashboard-card overflow-hidden">
        <div className="px-8 py-5 border-b border-border-warm flex items-center justify-between">
          <h3 className="text-[11px] font-extrabold text-slate-500 flex items-center gap-2 uppercase tracking-widest">
            <BarChartIcon className="w-3.5 h-3.5 text-primary" />
            Vectored Industry Benchmarking
          </h3>
        </div>
        <div className="p-8 h-80">
          <ResponsiveContainer width="100%" height="100%">
            <RechartsBar data={benchmarkData} barGap={16}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#EDF2F7" />
              <XAxis dataKey="name" stroke="#A0AEC0" fontSize={10} axisLine={false} tickLine={false} tick={{ fontWeight: 600 }} dy={10} />
              <YAxis stroke="#A0AEC0" fontSize={10} axisLine={false} tickLine={false} />
              <RechartsTooltip 
                cursor={{ fill: '#F7FAFC' }}
                contentStyle={{ backgroundColor: '#fff', border: 'none', borderRadius: '16px', fontSize: '11px', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)' }}
                itemStyle={{ fontSize: '11px', fontWeight: '800' }}
                formatter={(value: any, name: any) => [`${value.toLocaleString()}`, name]}
              />
              <Legend 
                verticalAlign="top" 
                height={36} 
                iconType="circle" 
                formatter={(val) => <span className="text-[11px] font-extrabold uppercase tracking-widest text-slate-500">{val}</span>}
              />
              <Bar dataKey="actual" name="Internal Flow" fill="#D4A373" radius={[6, 6, 0, 0]} barSize={24} />
              <Bar dataKey="benchmark" name="Market Median" fill="#E2E8F0" radius={[6, 6, 0, 0]} barSize={24} />
            </RechartsBar>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
