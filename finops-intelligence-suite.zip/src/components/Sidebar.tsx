import { 
  BarChart2, 
  Users, 
  Receipt, 
  FileText, 
  ShieldAlert, 
  Bot, 
  Settings, 
  LogOut, 
  LayoutDashboard,
  Wallet,
  Zap,
  Sparkles
} from 'lucide-react';
import { motion } from 'motion/react';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export function Sidebar({ activeTab, setActiveTab }: SidebarProps) {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'invoices', label: 'Invoices', icon: FileText },
    { id: 'clients', label: 'Clients', icon: Users },
    { id: 'expenses', label: 'Expenses', icon: Receipt },
    { id: 'reports', label: 'Reports', icon: BarChart2 },
    { id: 'taxes', label: 'Taxes', icon: ShieldAlert },
    { id: 'ai-assistant', label: 'AI Assistant', icon: Bot },
  ];

  return (
    <div className="w-64 h-screen bg-[#F8FAFC]/50 backdrop-blur-2xl border-r border-slate-200/40 flex flex-col fixed left-0 top-0 z-50">
      <div className="p-7 flex items-center gap-3">
        <div className="w-8 h-8 bg-slate-900 rounded-lg flex items-center justify-center shadow-lg shadow-slate-200">
          <Zap className="w-4 h-4 text-emerald-400 fill-emerald-400" />
        </div>
        <div>
          <h1 className="font-bold text-base tracking-tighter text-slate-900 leading-none">SmartLedger</h1>
          <p className="text-[9px] font-bold text-slate-400 uppercase tracking-[0.2em] mt-1 ml-0.5">Enterprise AI</p>
        </div>
      </div>

      <nav className="flex-1 px-4 mt-2 overflow-y-auto custom-scrollbar">
        <div className="space-y-0.5">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all duration-200 relative group truncate outline-none select-none ${
                activeTab === item.id
                  ? 'bg-white text-slate-900 font-bold shadow-sm border border-slate-100'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              {activeTab === item.id && (
                <motion.div 
                  layoutId="sidebar-accent"
                  className="absolute left-1.5 w-1 h-3.5 bg-slate-900 rounded-full"
                />
              )}
              <item.icon className={`w-4 h-4 flex-shrink-0 transition-all duration-200 ${activeTab === item.id ? 'text-slate-900' : 'text-slate-400 group-hover:text-slate-600'}`} />
              <span className="text-[13px] font-medium tracking-tight">{item.label}</span>
            </button>
          ))}
        </div>

        <div className="mt-8 pt-6 border-t border-slate-200/40 space-y-0.5">
          <button className="w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-slate-500 hover:bg-white hover:text-slate-900 transition-all group font-medium">
            <Settings className="w-4 h-4 text-slate-400 group-hover:text-slate-600" />
            <span className="text-[13px]">Settings</span>
          </button>
          <button className="w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-slate-500 hover:bg-white hover:text-slate-900 transition-all group font-medium">
            <LogOut className="w-4 h-4 text-slate-400 group-hover:text-rose-500" />
            <span className="text-[13px]">Log Out</span>
          </button>
        </div>
      </nav>

      <div className="p-5 mx-4 mb-8 bg-slate-950 rounded-[24px] relative overflow-hidden shadow-2xl shadow-slate-200 group/pro border border-white/5">
        <div className="relative z-10">
          <div className="flex items-center gap-2 mb-2">
             <div className="p-1.5 bg-white/5 rounded-lg border border-white/5">
               <Sparkles className="w-3 h-3 text-emerald-400" />
             </div>
             <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest leading-none">Pro Plan</span>
          </div>
          <h3 className="font-bold text-[13px] text-white tracking-tight mb-0.5">Strategic Scaling</h3>
          <p className="text-[10px] text-slate-500 mb-4 leading-normal font-medium">Unlock predictive audit nodes.</p>
          <button className="w-full bg-white text-slate-900 py-2.5 rounded-xl text-[10px] font-bold uppercase tracking-wider transition-all hover:bg-emerald-400 hover:text-slate-950 active:scale-95 shadow-lg shadow-black/20">
            UPGRADE
          </button>
        </div>
        <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500 opacity-5 blur-2xl group-hover/pro:opacity-10 transition-opacity" />
        <div className="absolute -bottom-10 -left-10 w-28 h-28 bg-indigo-500 opacity-10 blur-3xl" />
      </div>
    </div>
  );
}
