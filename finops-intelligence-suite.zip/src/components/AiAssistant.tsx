import { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Loader2, Sparkles, Command, ShieldCheck, TrendingUp, Info } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { chatWithFinanceAI } from '../services/geminiService';
import { useFinancial } from '../context/FinancialContext';
import Markdown from 'react-markdown';

interface Message {
  role: 'user' | 'model';
  content: string;
  timestamp: Date;
}

export function AiAssistant() {
  const { totals, expenses, timeframe } = useFinancial();
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'model',
      content: "Welcome to SmartLedger AI Intelligence Terminal. I am your specialized CMA financial strategic assistant. How can I assist with your fiscal analysis today?",
      timestamp: new Date()
    }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const handleSend = async () => {
    if (!input.trim() || isTyping) return;

    const userMessage: Message = {
      role: 'user',
      content: input,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    try {
      // Map to service history format
      const history = messages.map(msg => ({
        role: msg.role,
        parts: msg.content
      }));
      history.push({ role: 'user', parts: input });

      // Build context string
      const financialContext = `
        Current Financial State:
        - Revenue: ${totals.revenue}
        - Total Expenses: ${totals.expenses}
        - Pending Invoices: ${totals.pendingInvoices}
        - Tax Estimate: ${totals.taxEstimate}
        - Timeframe: ${timeframe}
        - Recent Expenses: ${expenses.slice(0, 5).map(e => `${e.vendor}: ${e.amount}`).join(', ')}
      `;

      const response = await chatWithFinanceAI(history, financialContext);
      
      const aiMessage: Message = {
        role: 'model',
        content: response,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, aiMessage]);
    } catch (error) {
      console.error("AI Error:", error);
      const errorMessage: Message = {
        role: 'model',
        content: "I encountered a synchronization error in my neural core. Please retry the transmission.",
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsTyping(false);
    }
  };

  const QuickActions = [
    { label: "Analyze Cash Flow", icon: TrendingUp },
    { label: "Audit Anomalies", icon: Command },
    { label: "Tax Optimization", icon: ShieldCheck },
    { label: "Market Forecast", icon: Info }
  ];

  return (
    <div className="flex flex-col h-[75vh] dashboard-card overflow-hidden">
      {/* Header */}
      <div className="px-8 py-4 border-b border-border-warm flex items-center justify-between bg-slate-50/50">
        <div className="flex items-center gap-3">
          <div className="p-1.5 bg-primary/10 rounded-lg">
            <Bot className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h3 className="text-[12px] font-extrabold text-[#1A202C] uppercase tracking-[0.2em]">Fiscal Intelligence Core</h3>
            <p className="text-[10px] text-accent-emerald font-bold uppercase tracking-widest flex items-center gap-1.5 mt-0.5">
              <span className="h-1.5 w-1.5 rounded-full bg-accent-emerald animate-pulse"></span>
              Neural Network Online
            </p>
          </div>
        </div>
        <div className="flex gap-2">
          <div className="w-2 h-2 rounded-full bg-slate-200"></div>
          <div className="w-2 h-2 rounded-full bg-slate-200"></div>
          <div className="w-2 h-2 rounded-full bg-primary"></div>
        </div>
      </div>

      {/* Chat Area */}
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-8 space-y-8 scrollbar-hide bg-[#FDFBF9]/30"
      >
        <AnimatePresence initial={false}>
          {messages.map((msg, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 10, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              className={`flex gap-6 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}
            >
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 shadow-sm border border-border-warm ${
                msg.role === 'user' ? 'bg-white' : 'bg-primary/10'
              }`}>
                {msg.role === 'user' ? (
                  <User className="w-5 h-5 text-slate-400" />
                ) : (
                  <Sparkles className="w-5 h-5 text-primary" />
                )}
              </div>
              <div className={`max-w-[80%] ${msg.role === 'user' ? 'text-right' : ''}`}>
                <div className={`inline-block px-6 py-4 rounded-2xl text-sm leading-relaxed shadow-sm border ${
                  msg.role === 'user' 
                    ? 'bg-primary text-white border-primary focus:shadow-lg' 
                    : 'bg-white text-slate-700 border-border-warm'
                }`}>
                  <div className="markdown-body prose prose-slate prose-sm max-w-none">
                    <Markdown>{msg.content}</Markdown>
                  </div>
                </div>
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-2">
                  {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </p>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
        
        {isTyping && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex gap-6"
          >
            <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0 animate-pulse border border-border-warm">
              <Bot className="w-5 h-5 text-primary" />
            </div>
            <div className="bg-white border border-border-warm px-6 py-4 rounded-2xl flex items-center gap-2 shadow-sm">
              <Loader2 className="w-4 h-4 text-primary animate-spin" />
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-widest animate-pulse">Deep Analysis in Progress...</span>
            </div>
          </motion.div>
        )}
      </div>

      {/* Input Area */}
      <div className="p-8 border-t border-border-warm bg-white">
        <div className="flex gap-3 mb-6 overflow-x-auto pb-2 scrollbar-hide">
          {QuickActions.map((action, i) => (
            <button
              key={i}
              onClick={() => setInput(action.label)}
              className="flex-shrink-0 flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-50 border border-border-warm hover:border-primary/30 hover:bg-primary/5 transition-all group"
            >
              <action.icon className="w-3.5 h-3.5 text-slate-400 group-hover:text-primary" />
              <span className="text-[11px] font-bold text-slate-600 group-hover:text-primary uppercase tracking-widest">{action.label}</span>
            </button>
          ))}
        </div>

        <div className="relative">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Ask AI for strategic financial insight..."
            className="w-full bg-[#FBF9F6] border border-border-warm rounded-2xl py-4 pl-6 pr-14 text-sm font-medium text-slate-700 focus:outline-none focus:border-primary/50 focus:shadow-[0_0_0_4px_rgba(139,94,60,0.05)] transition-all placeholder:text-slate-400"
          />
          <button
            onClick={handleSend}
            disabled={!input.trim() || isTyping}
            className="absolute right-3 top-1/2 -translate-y-1/2 w-10 h-10 bg-primary hover:bg-[#B28451] disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-xl flex items-center justify-center transition-all shadow-sm shadow-primary/20"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
        <p className="text-center text-[9px] font-extrabold text-slate-300 uppercase tracking-[0.3em] mt-4">
          Experimental AI Intelligence • Powered by SmartLedger Neural Engine
        </p>
      </div>
    </div>
  );
}
