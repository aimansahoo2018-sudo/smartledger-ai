import { useState } from 'react';
import { 
  ShieldAlert, TrendingUp, Info, ArrowUpRight, 
  Calendar, FileText, Download, PieChart,
  Activity, Scale, Wallet, AlertTriangle,
  ChevronRight, Calculator, CheckCircle2,
  Clock
} from 'lucide-react';
import { motion } from 'motion/react';
import { 
  PieChart as RechartsPie, Pie, Cell, ResponsiveContainer, 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend 
} from 'recharts';
import { useFinancial } from '../context/FinancialContext';

export function TaxDashboard() {
  const { totals, formatCurrency } = useFinancial();
  const [selectedFiscalYear, setSelectedFiscalYear] = useState('2024-25');

  const taxDistribution = [
    { name: 'Income Tax', value: 45000, color: '#D4A373' },
    { name: 'GST / VAT', value: 32000, color: '#10B981' },
    { name: 'Professional Tax', value: 8500, color: '#60A5FA' },
    { name: 'Social Security', value: 12000, color: '#F43F5E' },
  ];

  const taxTimeline = [
    { month: 'Apr', projected: 12000, actual: 11500 },
    { month: 'May', projected: 15000, actual: 14200 },
    { month: 'Jun', projected: 14000, actual: 0 },
    { month: 'Jul', projected: 16000, actual: 0 },
    { month: 'Aug', projected: 15500, actual: 0 },
    { month: 'Sep', projected: 18000, actual: 0 },
  ];

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-3 mb-1">
            <h2 className="text-2xl font-extrabold text-[#1A202C] tracking-tight text-left">Tax Intelligence Terminal</h2>
            <div className="px-2 py-0.5 bg-emerald-50 text-emerald-600 text-[10px] font-black rounded border border-emerald-100 uppercase tracking-widest">Compliant</div>
          </div>
          <p className="text-sm font-medium text-slate-500 text-left">Automated fiscal estimation and tax liability profiling.</p>
        </div>
        <div className="flex items-center gap-3">
          <select 
            value={selectedFiscalYear}
            onChange={(e) => setSelectedFiscalYear(e.target.value)}
            className="bg-white border border-border-warm rounded-xl px-4 py-2.5 text-xs font-bold text-slate-600 outline-none cursor-pointer hover:border-primary/50 transition-all shadow-sm"
          >
            <option>FY 2024-25</option>
            <option>FY 2023-24</option>
          </select>
          <button className="bg-white border border-border-warm hover:bg-slate-50 text-slate-600 px-5 py-2.5 rounded-xl font-bold text-xs flex items-center gap-2 shadow-sm transition-all uppercase tracking-widest">
            <Download className="w-4 h-4" />
            Tax Report
          </button>
        </div>
      </div>

      {/* Main Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="dashboard-card p-8 bg-primary/5 border-primary/20 relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-8 text-primary/10 group-hover:scale-110 transition-transform">
            <Calculator className="w-20 h-20" />
          </div>
          <div className="relative z-10">
            <p className="text-[10px] font-extrabold text-primary uppercase tracking-[0.2em] mb-2">Estimated Liability</p>
            <h3 className="text-4xl font-extrabold text-[#1A202C] tracking-tight">{formatCurrency(totals.taxEstimate)}</h3>
            <div className="flex items-center gap-2 mt-4">
              <span className="text-[11px] font-black text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-100 uppercase tracking-widest">- 4.2%</span>
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Compared to prev year</span>
            </div>
          </div>
        </div>

        <div className="dashboard-card p-8">
          <p className="text-[10px] font-extrabold text-slate-400 uppercase tracking-[0.2em] mb-4">Upcoming Deadlines</p>
          <div className="space-y-6">
            {[
              { label: 'Q1 GST Filing', date: 'June 20, 2026', type: 'Hard', status: 'Pending' },
              { label: 'Advance Tax P1', date: 'June 15, 2026', type: 'Payment', status: 'Due Soon' },
            ].map((d, i) => (
              <div key={i} className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-xl bg-slate-50 border border-border-warm flex flex-col items-center justify-center">
                  <Calendar className="w-4 h-4 text-slate-400" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900 leading-tight">{d.label}</h4>
                  <p className="text-[11px] text-slate-500 font-medium mt-0.5">{d.date}</p>
                  <span className={`inline-block mt-2 px-2 py-0.5 rounded text-[9px] font-black uppercase tracking-widest ${d.status === 'Pending' ? 'bg-amber-50 text-amber-600 border border-amber-100' : 'bg-rose-50 text-rose-600 border border-rose-100'}`}>
                    {d.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="dashboard-card p-8 bg-[#FBF9F6]">
          <p className="text-[10px] font-extrabold text-slate-400 uppercase tracking-[0.2em] mb-6">Optimization Potential</p>
          <div className="flex items-center gap-5">
            <div className="w-16 h-16 rounded-full border-4 border-emerald-500/20 border-t-emerald-500 flex items-center justify-center text-emerald-600">
              <TrendingUp className="w-7 h-7" />
            </div>
            <div>
              <h4 className="text-xl font-extrabold text-[#1A202C]">{formatCurrency(42500)}</h4>
              <p className="text-[11px] text-slate-500 font-medium leading-relaxed max-w-[140px]">Available tax savings identified by AI audit.</p>
            </div>
          </div>
          <button className="w-full mt-6 bg-[#B28451] hover:bg-[#966E43] text-white py-2.5 rounded-xl text-xs font-extrabold uppercase tracking-widest transition-all shadow-md flex items-center justify-center gap-2">
            View Strategies
            <ArrowUpRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Visual Analysis */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="dashboard-card p-8">
          <div className="flex items-center justify-between mb-8">
            <h3 className="font-extrabold text-[#1A202C] text-lg text-left">Tax Distribution</h3>
            <div className="p-2 bg-slate-50 rounded-lg">
              <PieChart className="w-4 h-4 text-slate-400" />
            </div>
          </div>
          <div className="h-[280px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <RechartsPie>
                <Pie
                  data={taxDistribution}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {taxDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ 
                    borderRadius: '16px', 
                    border: 'none', 
                    boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)',
                    padding: '12px 16px'
                  }} 
                />
              </RechartsPie>
            </ResponsiveContainer>
          </div>
          <div className="grid grid-cols-2 gap-4 mt-8">
            {taxDistribution.map((item, i) => (
              <div key={i} className="flex items-center gap-3">
                <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: item.color }} />
                <span className="text-[11px] font-bold text-slate-600 uppercase tracking-widest">{item.name}</span>
                <span className="ml-auto text-sm font-extrabold text-slate-900">{formatCurrency(item.value)}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="dashboard-card p-8">
          <div className="flex items-center justify-between mb-8">
            <h3 className="font-extrabold text-[#1A202C] text-lg text-left">Filing Projections</h3>
            <div className="flex gap-4">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-slate-200" />
                <span className="text-[10px] font-bold text-slate-400 uppercase">Projected</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-primary" />
                <span className="text-[10px] font-bold text-slate-400 uppercase">Paid</span>
              </div>
            </div>
          </div>
          <div className="h-[320px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={taxTimeline}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
                <XAxis 
                  dataKey="month" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fill: '#94A3B8', fontSize: 10, fontWeight: 700 }} 
                />
                <YAxis 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fill: '#94A3B8', fontSize: 10, fontWeight: 700 }} 
                />
                <Tooltip 
                  cursor={{ fill: '#F1F5F9' }}
                  contentStyle={{ 
                    borderRadius: '16px', 
                    border: 'none', 
                    boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)',
                    padding: '12px 16px'
                  }} 
                />
                <Bar dataKey="projected" fill="#E2E8F0" radius={[4, 4, 0, 0]} />
                <Bar dataKey="actual" fill="#D4A373" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="dashboard-card p-8 bg-slate-900 text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-20" />
        <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-8">
          <div>
            <h3 className="text-xl font-extrabold mb-2 tracking-tight">Audit Readiness Index</h3>
            <p className="text-slate-400 text-sm font-medium leading-relaxed max-w-lg">Your business documentation has been cross-referenced with local tax codes. You are currently in the low-risk category with 98.4% data integrity.</p>
          </div>
          <div className="flex flex-col items-center">
            <div className="text-4xl font-black text-emerald-400 tracking-tighter">98.4%</div>
            <div className="mt-2 flex gap-1">
              {[1, 2, 3, 4, 5].map((s) => (
                <div key={s} className={`h-1.5 w-6 rounded-full ${s <= 4 ? 'bg-emerald-400' : 'bg-slate-700'}`} />
              ))}
            </div>
          </div>
          <button className="bg-white text-slate-900 px-8 py-3 rounded-xl font-bold text-sm uppercase tracking-widest hover:bg-slate-50 transition-all flex items-center gap-3">
            <ShieldAlert className="w-4 h-4" />
            Compliance Check
          </button>
        </div>
      </div>
    </div>
  );
}
