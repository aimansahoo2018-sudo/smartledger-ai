import { useState, useRef } from 'react';
import { Upload, FileText, CheckCircle2, AlertTriangle, Loader2, Search, Filter, ArrowUpRight, DollarSign } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useFinancial, CostType, CostBehavior } from '../context/FinancialContext';
import { classifyExpenses } from '../services/geminiService';

export function InvoiceManager() {
  const { addExpenses, formatCurrency } = useFinancial();
  const [isUploading, setIsUploading] = useState(false);
  const [uploadStatus, setUploadStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    setUploadStatus('idle');

    try {
      // simulate file processing/OCR
      await new Promise(resolve => setTimeout(resolve, 2000));

      // Mock OCR results
      const mockResult = [
        {
          id: `inv-${Date.now()}`,
          vendor: file.name.split('.')[0] || 'Unknown Vendor',
          amount: Math.floor(Math.random() * 5000) + 500,
          date: new Date().toISOString().split('T')[0],
          description: `Extracted from invoice: ${file.name}`
        }
      ];

      const classified = await classifyExpenses(mockResult);
      const finalExpenses = mockResult.map(raw => {
        const result = classified.find((r: any) => r.id === raw.id);
        return { ...raw, ...result, costType: result?.costType || CostType.INDIRECT, costBehavior: result?.costBehavior || CostBehavior.VARIABLE };
      });

      addExpenses(finalExpenses as any);
      setUploadStatus('success');
      
      // Visual feedback via console (we could add a toast here if we had one)
      console.log('Finance Engine Synchronized:', finalExpenses);
    } catch (error) {
      console.error(error);
      setUploadStatus('error');
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  return (
    <div className="space-y-8">
      {/* Hero Upload Zone */}
      <div className="bg-white border-2 border-dashed border-border-warm rounded-[24px] p-12 text-center hover:border-primary/50 transition-all group relative overflow-hidden">
        <div className="absolute inset-0 bg-primary/[0.02] opacity-0 group-hover:opacity-100 transition-opacity" />
        
        <input 
          type="file" 
          className="hidden" 
          ref={fileInputRef}
          onChange={handleFileUpload}
        />

        <div className="relative z-10 flex flex-col items-center">
          <div className="w-16 h-16 bg-slate-50 rounded-2xl flex items-center justify-center border border-border-warm mb-6 group-hover:scale-110 transition-transform">
            {isUploading ? (
              <Loader2 className="w-8 h-8 text-primary animate-spin" />
            ) : uploadStatus === 'success' ? (
              <CheckCircle2 className="w-8 h-8 text-accent-emerald" />
            ) : (
              <Upload className="w-8 h-8 text-slate-400 group-hover:text-primary" />
            )}
          </div>
          
          <h3 className="text-xl font-extrabold text-[#1A202C] mb-2">Upload Digital Invoice</h3>
          <p className="text-slate-500 text-sm max-w-xs mx-auto leading-relaxed mb-8 font-medium">
            Drag and drop your PDF, JPG or PNG invoices here. Our AI will automatically classify line items.
          </p>

          <button 
            onClick={() => fileInputRef.current?.click()}
            disabled={isUploading}
            className="bg-[#D4A373] hover:bg-[#B28451] disabled:opacity-50 text-white px-8 py-3 rounded-xl font-bold text-sm uppercase tracking-widest shadow-md shadow-primary/20 transition-all flex items-center gap-3"
          >
            {isUploading ? 'Extracting Data...' : 'Browse Documents'}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-xs font-bold text-slate-400 uppercase tracking-[0.2em]">Recent Document Log</h2>
            <div className="flex gap-4">
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input 
                  type="text" 
                  placeholder="Search invoices..." 
                  className="bg-white border border-border-warm rounded-lg pl-9 pr-4 py-1.5 text-xs font-semibold text-slate-600 outline-none focus:border-primary/50"
                />
              </div>
              <button className="p-2 border border-border-warm rounded-lg hover:bg-slate-50 text-slate-400">
                <Filter className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="dashboard-card p-5 flex items-center gap-6 hover:shadow-md transition-all group cursor-pointer">
                <div className="w-12 h-12 rounded-xl bg-slate-50 border border-border-warm flex items-center justify-center text-slate-400 group-hover:text-primary group-hover:bg-primary/5 transition-all">
                  <FileText className="w-6 h-6" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <h4 className="text-sm font-bold text-slate-900">Service_Agreement_Q{i}.pdf</h4>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{10 + i} May 2024</span>
                  </div>
                  <div className="flex items-center gap-4 text-[11px] text-slate-500 font-medium">
                    <span className="flex items-center gap-1.5 uppercase font-bold text-slate-800">
                      {formatCurrency(Math.floor(Math.random() * 5000) + 1000)}
                    </span>
                    <span className="w-1 h-1 rounded-full bg-slate-200" />
                    <span className="px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-600 text-[9px] font-bold">Processed</span>
                  </div>
                </div>
                <button className="p-2 text-slate-300 hover:text-primary transition-colors">
                  <ArrowUpRight className="w-5 h-5" />
                </button>
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-6">
          <h2 className="text-xs font-bold text-slate-400 uppercase tracking-[0.2em]">Upload Statistics</h2>
          <div className="dashboard-card p-8 bg-[#FBF9F6]/50">
            <div className="text-center mb-8">
              <span className="text-4xl font-extrabold text-[#1A202C] tracking-tight">142</span>
              <p className="text-[10px] font-extrabold text-slate-400 uppercase tracking-[0.2em] mt-2">Invoices Digitalized</p>
            </div>
            
            <div className="space-y-6">
              {[
                { label: 'Cloud Services', count: 42, color: 'bg-primary' },
                { label: 'Vendor Invoices', count: 86, color: 'bg-emerald-500' },
                { label: 'Utility Bills', count: 14, color: 'bg-rose-400' }
              ].map((stat, i) => (
                <div key={i}>
                  <div className="flex justify-between items-center text-[10px] font-extrabold uppercase tracking-widest mb-2">
                    <span className="text-slate-600">{stat.label}</span>
                    <span className="text-slate-400">{stat.count}</span>
                  </div>
                  <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
                    <div 
                      className={`h-full ${stat.color} transition-all duration-1000`}
                      style={{ width: `${(stat.count / 142) * 100}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-10 p-4 bg-white border border-border-warm rounded-2xl flex items-center gap-4">
              <div className="p-2 bg-emerald-50 rounded-lg">
                <CheckCircle2 className="w-4 h-4 text-emerald-500" />
              </div>
              <div className="text-[10px] font-bold text-slate-500 leading-relaxed capitalize">
                Sync status: <span className="text-emerald-600">Encrypted Cloud vault synchronized</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
