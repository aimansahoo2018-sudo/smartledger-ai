import { Search, Bell, Settings, User, Globe, Plus, Sparkles, Loader2, X, ArrowRight } from 'lucide-react';
import { useFinancial } from '../context/FinancialContext';
import { useState, useRef, useEffect } from 'react';
import { chatWithFinanceAI } from '../services/geminiService';
import { motion, AnimatePresence } from 'motion/react';
import Markdown from 'react-markdown';

interface TopBarProps {
  title: string;
}

export function TopBar({ title }: TopBarProps) {
  const { currency, setCurrency, searchQuery, setSearchQuery, setActiveTab, totals, expenses, timeframe } = useFinancial();
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [aiAnswer, setAiAnswer] = useState<string | null>(null);
  const [showAiOverlay, setShowAiOverlay] = useState(false);
  
  const handleSearchKeyDown = async (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && searchQuery.trim()) {
      setIsAiLoading(true);
      setShowAiOverlay(true);
      setAiAnswer(null);
      
      try {
        const financialContext = `
          Current Financial State:
          - Revenue: ${totals.revenue}
          - Total Expenses: ${totals.expenses}
          - Pending Invoices: ${totals.pendingInvoices}
          - Tax Estimate: ${totals.taxEstimate}
          - Timeframe: ${timeframe}
          - Recent Expenses: ${expenses.slice(0, 5).map(e => `${e.vendor}: ${e.amount}`).join(', ')}
        `;

        const response = await chatWithFinanceAI([
          { role: 'user', parts: searchQuery }
        ], financialContext);
        
        setAiAnswer(response || "I couldn't find a specific answer for that.");
      } catch (error) {
        setAiAnswer("Failed to synchronize with financial data. Please try again.");
      } finally {
        setIsAiLoading(false);
      }
    }
  };

  return (
    <header className="h-16 bg-white/60 backdrop-blur-xl flex items-center justify-between px-8 sticky top-0 z-40 transition-all border-b border-slate-200/40">
      <div className="flex-1 max-w-lg relative items-center flex gap-4">
        <div className="relative w-full group">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400 group-focus-within:text-slate-900 transition-colors" />
          <input 
            type="text" 
            placeholder="Ask SmartLedger AI about your finances..." 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyDown={handleSearchKeyDown}
            className="w-full bg-[#f1f5f9]/50 border border-transparent rounded-xl px-10 py-2 text-[13px] focus:outline-none focus:ring-1 focus:ring-slate-200 focus:bg-white focus:border-slate-200 transition-all shadow-sm group-hover:bg-[#f1f5f9]"
          />
          {searchQuery && !showAiOverlay && (
             <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-1.5 pointer-events-none">
                <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider bg-white px-1.5 py-0.5 rounded border border-slate-100 shadow-sm">Enter to Ask AI</span>
             </div>
          )}
        </div>

        <AnimatePresence>
          {showAiOverlay && (
            <>
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setShowAiOverlay(false)}
                className="fixed inset-0 bg-slate-900/[0.02] backdrop-blur-[2px] z-[60]"
              />
              <motion.div 
                initial={{ opacity: 0, y: 8, scale: 0.98 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 8, scale: 0.98 }}
                className="absolute top-12 left-0 w-full bg-white rounded-[24px] shadow-2xl shadow-slate-200/50 border border-slate-200/60 z-[70] overflow-hidden"
              >
                <div className="p-6">
                  <div className="flex items-center justify-between mb-5">
                    <div className="flex items-center gap-2.5">
                       <div className="p-1.5 bg-indigo-50 rounded-lg">
                        <Sparkles className="w-3.5 h-3.5 text-indigo-600 animate-pulse" />
                       </div>
                       <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Financial Intelligence Signal</span>
                    </div>
                    <button 
                      onClick={() => setShowAiOverlay(false)}
                      className="p-1.5 hover:bg-slate-50 rounded-full transition-colors"
                    >
                      <X className="w-3.5 h-3.5 text-slate-400" />
                    </button>
                  </div>

                  <div className="min-h-[80px] flex flex-col">
                    {isAiLoading ? (
                      <div className="flex-1 flex flex-col items-center justify-center py-10 gap-4">
                         <Loader2 className="w-5 h-5 text-indigo-600 animate-spin" />
                         <p className="text-[11px] font-semibold text-slate-400 animate-pulse uppercase tracking-[0.15em]">Analyzing Financial Vectors</p>
                      </div>
                    ) : (
                      <div className="prose prose-slate prose-sm max-w-none">
                        <div className="text-[13px] leading-relaxed text-slate-600">
                          <Markdown>{aiAnswer || ''}</Markdown>
                        </div>
                        <div className="mt-8 pt-4 border-t border-slate-100 flex justify-end">
                           <button 
                            onClick={(e) => {
                              setShowAiOverlay(false);
                              setActiveTab('ai-assistant');
                            }}
                            className="flex items-center gap-2 text-[11px] font-bold text-slate-900 uppercase tracking-widest hover:gap-3 transition-all"
                           >
                             Full Strategy Audit
                             <ArrowRight className="w-3.5 h-3.5" />
                           </button>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </motion.div>
            </>
          )}
        </AnimatePresence>
      </div>

      <div className="flex items-center gap-6">
        <div className="hidden lg:flex items-center gap-2.5">
          <button 
            onClick={() => setActiveTab('invoices')}
            className="h-9 bg-white border border-slate-200 hover:border-slate-300 text-slate-700 px-4 rounded-xl text-[11px] font-bold uppercase tracking-wider transition-all flex items-center gap-2 active:scale-95"
          >
            <Plus className="w-3.5 h-3.5 text-slate-400" />
            Invoice
          </button>
          <button 
            onClick={() => setActiveTab('ai-assistant')}
            className="h-9 bg-slate-900 hover:bg-slate-800 text-white px-4 rounded-xl text-[11px] font-bold uppercase tracking-wider transition-all flex items-center gap-2 shadow-lg shadow-slate-900/10 group active:scale-95"
          >
            <Sparkles className="w-3.5 h-3.5 text-emerald-400 group-hover:scale-110 transition-transform" />
            Ask AI
          </button>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 px-2.5 h-9 bg-slate-50 border border-slate-200 rounded-xl hover:bg-white hover:border-slate-300 transition-all cursor-pointer group">
            <Globe className="w-3.5 h-3.5 text-slate-400 group-hover:text-slate-600 transition-colors" />
            <select 
              value={currency}
              onChange={(e) => setCurrency(e.target.value)}
              className="text-[10px] font-bold text-slate-700 outline-none cursor-pointer bg-transparent uppercase tracking-wider appearance-none pr-1"
            >
              <option value="INR">₹ INR</option>
              <option value="PKR">Rs PKR</option>
              <option value="USD">$ USD</option>
              <option value="EUR">€ EUR</option>
              <option value="GBP">£ GBP</option>
              <option value="AED">د.إ AED</option>
            </select>
          </div>

          <div className="flex items-center gap-1">
            <button className="w-9 h-9 flex items-center justify-center rounded-xl hover:bg-slate-50 text-slate-400 hover:text-slate-600 transition-all relative group">
              <Bell className="w-4.5 h-4.5" />
              <span className="absolute top-2.5 right-2.5 w-1.5 h-1.5 bg-rose-500 rounded-full border-2 border-white shadow-sm" />
            </button>
          </div>
          
          <div className="h-5 w-[1px] bg-slate-200 mx-1" />
          
          <div className="flex items-center gap-3 pl-1">
            <div className="hidden md:block text-right">
              <p className="text-[12px] font-bold text-slate-900 leading-none">aiman ismail</p>
              <div className="flex items-center justify-end gap-1 mt-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.3)]" />
                <p className="text-[9px] text-slate-400 font-bold uppercase tracking-widest">Enterprise</p>
              </div>
            </div>
            <div className="w-8 h-8 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-center overflow-hidden hover:border-slate-300 transition-all cursor-pointer">
              <User className="w-4 h-4 text-slate-400" />
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
