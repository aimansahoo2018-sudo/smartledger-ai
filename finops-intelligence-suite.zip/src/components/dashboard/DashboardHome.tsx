import { ExecutiveSummary } from './ExecutiveSummary';
import { StatsGrid } from './StatsGrid';
import { IncomeExpenseDonut } from './IncomeExpenseDonut';
import { CashFlowArea } from './CashFlowArea';
import { TopExpensesList } from './TopExpensesList';
import { AiInsightsCard } from './AiInsightsCard';
import { RecentTransactions } from './RecentTransactions';
import { CashFlowAnalytics } from './CashFlowAnalytics';
import { useFinancial } from '../../context/FinancialContext';

export function DashboardHome() {
  const { totals, expenses, searchQuery, timeframe, setTimeframe } = useFinancial();

  const filteredExpenses = expenses.filter(e => 
    e.vendor.toLowerCase().includes(searchQuery.toLowerCase()) ||
    e.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
    e.costCenter.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6 pb-12">
      <ExecutiveSummary />
      
      <StatsGrid timeframe={timeframe} totals={totals} />
      
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-8 space-y-6">
          <CashFlowArea timeframe={timeframe} expenses={filteredExpenses} />
          <RecentTransactions />
        </div>
        
        <div className="lg:col-span-4 space-y-6">
          <CashFlowAnalytics />
          <AiInsightsCard />
          <IncomeExpenseDonut timeframe={timeframe} setTimeframe={setTimeframe} totals={totals} />
          <TopExpensesList expenses={filteredExpenses} />
        </div>
      </div>
    </div>
  );
}
