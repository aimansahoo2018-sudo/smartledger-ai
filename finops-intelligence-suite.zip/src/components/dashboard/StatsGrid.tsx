import { ArrowUpRight, ArrowDownRight, Activity } from 'lucide-react';
import { motion } from 'motion/react';
import { useFinancial } from '../../context/FinancialContext';
import { ResponsiveContainer, AreaChart, Area } from 'recharts';

export function StatsGrid({ timeframe, totals }: { timeframe: string, totals: any }) {
  const { formatCurrency } = useFinancial();
  
  // Mock sparkline data
  const data = [
    { v: 40 }, { v: 45 }, { v: 42 }, { v: 50 }, { v: 55 }, { v: 52 }, { v: 60 }
  ];

  const stats = [
    { label: 'Net Liquidity', value: formatCurrency(totals.revenue), trend: '+12.5%', isPositive: true },
    { label: 'Total OpEx', value: formatCurrency(totals.expenses), trend: '+8.2%', isPositive: false },
    { label: 'Unsettled Ledger', value: formatCurrency(totals.pendingInvoices), sub: 'Pending Review', isNeutral: true },
    { label: 'Provisioned Tax', value: formatCurrency(totals.taxEstimate), sub: 'Q3 Estimate', isNeutral: true },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
      {stats.map((stat, i) => (
        <motion.div 
          key={i} 
          whileHover={{ y: -2 }}
          className="bg-white border border-slate-100 p-5 rounded-[24px] flex flex-col justify-between h-36 cursor-pointer group hover:border-slate-200 transition-all shadow-sm relative overflow-hidden"
        >
          <div className="relative z-10 flex justify-between items-start">
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.15em] group-hover:text-slate-900 transition-colors">{stat.label}</p>
            {stat.trend ? (
              <div className={`px-1.5 py-0.5 rounded-md text-[9px] font-bold flex items-center gap-1 border ${
                stat.isPositive ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 'bg-rose-50 text-rose-600 border-rose-100'
              }`}>
                {stat.trend}
              </div>
            ) : (
              <Activity className="w-3 h-3 text-slate-300" />
            )}
          </div>
          
          <div className="relative z-10">
            <h3 className="text-2xl font-bold text-slate-900 tracking-tight tabular-nums group-hover:scale-[1.02] transition-transform origin-left">{stat.value}</h3>
            <p className="text-[10px] font-medium text-slate-400 mt-1 uppercase tracking-wider">
              {stat.sub || (stat.isPositive ? 'Accelerating Trend' : 'Standard Variance')}
            </p>
          </div>

          {/* Mini Sparkline Background */}
          <div className="absolute bottom-0 left-0 right-0 h-12 opacity-30 group-hover:opacity-50 transition-opacity">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data}>
                <defs>
                  <linearGradient id={`gradient-${i}`} x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor={stat.isPositive ? "#10B981" : stat.isNeutral ? "#94A3B8" : "#F43F5E"} stopOpacity={0.3}/>
                    <stop offset="95%" stopColor={stat.isPositive ? "#10B981" : stat.isNeutral ? "#94A3B8" : "#F43F5E"} stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <Area 
                  type="monotone" 
                  dataKey="v" 
                  stroke={stat.isPositive ? "#10B981" : stat.isNeutral ? "#94A3B8" : "#F43F5E"} 
                  strokeWidth={1.5}
                  fill={`url(#gradient-${i})`} 
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </motion.div>
      ))}
    </div>
  );
}
