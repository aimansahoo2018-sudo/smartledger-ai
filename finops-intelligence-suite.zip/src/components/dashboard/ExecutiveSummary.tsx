import { motion } from 'motion/react';
import { Sparkles, TrendingUp, ShieldAlert, Clock, Zap } from 'lucide-react';
import { useFinancial } from '../../context/FinancialContext';

export function ExecutiveSummary() {
  const { totals, formatCurrency } = useFinancial();
  
  const insights = [
    { 
      label: 'EBITDA Velocity', 
      value: '+15.2%', 
      detail: 'Vs last Q', 
      icon: TrendingUp, 
      color: 'bg-emerald-50 text-emerald-600 border-emerald-100' 
    },
    { 
      label: 'Fiscal Anomaly', 
      value: 'None Detected', 
      detail: 'Real-time', 
      icon: ShieldAlert, 
      color: 'bg-emerald-50 text-emerald-600 border-emerald-100' 
    },
    { 
      label: 'Runway AI', 
      value: '22 Months', 
      detail: 'Strategic', 
      icon: Clock, 
      color: 'bg-indigo-50 text-indigo-600 border-indigo-100' 
    }
  ];

  return (
    <div className="flex flex-col lg:flex-row gap-5">
      {/* Welcome & Pulse */}
      <div className="flex-1 dashboard-card p-6 border-l-4 border-slate-900 relative overflow-hidden group">
        <div className="absolute top-0 right-0 w-48 h-48 bg-slate-50 opacity-40 rounded-full blur-3xl -mr-24 -mt-24 pointer-events-none" />
        
        <div className="flex justify-between items-start mb-4 relative z-10">
          <div>
            <h2 className="text-2xl font-bold text-slate-900 tracking-tight leading-none mb-1.5 flex items-center gap-2">
              Financial Status
              <span className="inline-flex items-center px-1.5 py-0.5 rounded-md bg-emerald-50 text-[9px] font-bold text-emerald-600 uppercase tracking-widest border border-emerald-100">Optimal</span>
            </h2>
            <p className="text-[12px] text-slate-500 font-medium tracking-tight">AI-generated financial health mapping</p>
          </div>
          <div className="p-2.5 bg-slate-900 rounded-xl shadow-lg ring-4 ring-slate-50 group-hover:scale-105 transition-transform duration-500">
            <Sparkles className="w-4 h-4 text-emerald-400 fill-emerald-400/20" />
          </div>
        </div>
        
        <div className="flex items-center gap-8 py-2 relative z-10">
          <div className="flex-1 min-w-[140px]">
            <p className="text-[9px] font-bold text-slate-400 uppercase tracking-[0.15em] mb-1">Projected NOI</p>
            <div className="flex items-baseline gap-2">
              <h3 className="text-3xl font-bold text-slate-900 tracking-tight tabular-nums">
                {formatCurrency(totals.revenue - totals.expenses)}
              </h3>
              <span className="text-emerald-500 text-[11px] font-bold">+12.4%</span>
            </div>
          </div>
          <div className="h-10 w-[1px] bg-slate-100" />
          <div className="flex-1">
            <p className="text-[9px] font-bold text-slate-400 uppercase tracking-[0.15em] mb-1">Cash Flow Scoring</p>
            <div className="flex items-center gap-3">
              <div className="flex-1 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: '92%' }}
                  className="h-full bg-slate-900 rounded-full"
                />
              </div>
              <span className="text-xl font-bold text-slate-900 tracking-tight">92<span className="text-xs text-slate-400 font-medium ml-0.5">/100</span></span>
            </div>
          </div>
        </div>
        
        <div className="mt-6 pt-5 border-t border-slate-100 relative z-10">
          <div className="p-3.5 bg-slate-50/50 rounded-2xl border border-slate-100/50 flex items-center gap-3 transition-all hover:bg-white hover:border-slate-200 group/ai">
            <div className="w-7 h-7 rounded-lg bg-white shadow-sm border border-slate-100 flex items-center justify-center group-hover/ai:border-indigo-200 transition-colors">
               <Zap className="w-3.5 h-3.5 text-indigo-500 fill-indigo-500/10" />
            </div>
            <p className="text-[12px] font-medium text-slate-600 leading-normal">
              <span className="text-slate-900 font-bold uppercase text-[9px] tracking-wider mr-2">Market Pulse:</span> 
              Revenue velocity is outpacing burn. AI recommends <span className="text-indigo-600 font-semibold cursor-pointer hover:underline">liquidity reallocation</span> for Q3 growth.
            </p>
          </div>
        </div>
      </div>

      {/* Quick Stats Grid */}
      <div className="lg:w-[320px] flex flex-col gap-2.5">
        {insights.map((insight, i) => (
          <motion.div 
            key={i}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="flex items-center gap-3 p-3.5 rounded-2xl border border-slate-100 bg-white shadow-sm transition-all hover:border-slate-200 cursor-pointer group"
          >
            <div className={`p-2 rounded-lg ${insight.color.split(' ')[0]} ${insight.color.split(' ')[1]} shadow-sm group-hover:scale-105 transition-transform`}>
              <insight.icon className="w-3.5 h-3.5" />
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between mb-0.5">
                <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">{insight.label}</p>
                <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded bg-slate-50 text-slate-500 border border-slate-100`}>{insight.detail}</span>
              </div>
              <span className="text-[14px] font-bold tracking-tight text-slate-900">{insight.value}</span>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
