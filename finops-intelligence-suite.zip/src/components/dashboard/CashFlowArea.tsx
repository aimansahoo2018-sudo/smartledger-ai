import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Expense, useFinancial } from '../../context/FinancialContext';

export function CashFlowArea({ timeframe, expenses }: { timeframe: string, expenses: Expense[] }) {
  const { formatCurrency, currency } = useFinancial();
  const isYear = timeframe === 'This Year';
  
  const totalExpenses = expenses.reduce((sum, e) => sum + e.amount, 0);

  const yearData = [
    { date: 'Jan', income: 450000, expense: 200000, predicted: 450000 },
    { date: 'Mar', income: 520000, expense: 300000, predicted: 520000 },
    { date: 'May', income: 650000, expense: 280000, predicted: 650000 },
    { date: 'Jul', income: 580000, expense: 350000, predicted: 580000 },
    { date: 'Sep', income: 720000, expense: 320000, predicted: 720000 },
    { date: 'Oct', predicted: 750000 },
    { date: 'Nov', predicted: 780000 },
    { date: 'Dec', income: 842300, expense: totalExpenses, predicted: 842300 },
  ];

  const monthData = [
    { date: '1 May', income: 45000, expense: 20000, predicted: 45000 },
    { date: '7 May', income: 38000, expense: 25000, predicted: 38000 },
    { date: '13 May', income: 52000, expense: 30000, predicted: 52000 },
    { date: '19 May', income: 48000, expense: 35000, predicted: 48000 },
    { date: '21 May', income: 65000, expense: 28000, predicted: 65000 },
    { date: '25 May', predicted: 68000 },
    { date: '31 May', income: 72000, expense: totalExpenses / 10, predicted: 72000 },
  ];

  const data = isYear ? yearData : monthData;

  const currencySymbol = currency === 'PKR' ? 'Rs' : currency === 'INR' ? '₹' : '$';

  return (
    <div className="dashboard-card p-6">
      <div className="flex justify-between items-start mb-8">
        <div>
            <h3 className="font-bold text-slate-900 text-base tracking-tight">Liquidity Vectors</h3>
            <p className="text-[11px] text-slate-500 font-medium mt-1">Strategic cash velocity & AI-forecasted runway</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5">
            <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.3)]" />
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Inflow</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-1.5 h-1.5 rounded-full bg-slate-900 shadow-sm" />
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Outflow</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-1.5 h-1.5 rounded-full border border-indigo-400 border-dashed" />
            <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest">Forecast</span>
          </div>
        </div>
      </div>

      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data}>
            <defs>
              <linearGradient id="colorIncome" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#10B981" stopOpacity={0.12}/>
                <stop offset="95%" stopColor="#10B981" stopOpacity={0}/>
              </linearGradient>
              <linearGradient id="colorExpense" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#0F172A" stopOpacity={0.08}/>
                <stop offset="95%" stopColor="#0F172A" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="4 4" vertical={false} stroke="#E2E8F0" opacity={0.4} />
            <XAxis 
              dataKey="date" 
              axisLine={false} 
              tickLine={false} 
              tick={{ fill: '#94A3B8', fontSize: 10, fontWeight: 600 }} 
              dy={10}
            />
            <YAxis 
              axisLine={false} 
              tickLine={false} 
              tick={{ fill: '#94A3B8', fontSize: 10, fontWeight: 600 }}
              tickFormatter={(value) => `${currencySymbol}${value >= 1000 ? value/1000 + 'k' : value}`}
            />
            <Tooltip 
              contentStyle={{ 
                borderRadius: '16px', 
                border: '1px solid rgba(226, 232, 240, 0.6)', 
                boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)',
                padding: '12px',
                background: 'rgba(255, 255, 255, 0.95)',
                backdropFilter: 'blur(8px)'
              }}
              itemStyle={{ fontSize: '11px', fontWeight: '700' }}
              labelStyle={{ color: '#64748B', fontSize: '9px', fontWeight: '700', textTransform: 'uppercase', marginBottom: '8px', letterSpacing: '0.05em' }}
              formatter={(value: any) => [formatCurrency(value), '']}
            />
            <Area 
              type="monotone" 
              dataKey="income" 
              stroke="#10B981" 
              strokeWidth={2}
              fillOpacity={1} 
              fill="url(#colorIncome)" 
              animationDuration={1500}
            />
            <Area 
              type="monotone" 
              dataKey="expense" 
              stroke="#0F172A" 
              strokeWidth={2}
              fillOpacity={1} 
              fill="url(#colorExpense)" 
              animationDuration={2000}
            />
             <Area 
              type="monotone" 
              dataKey="predicted" 
              stroke="#6366F1" 
              strokeWidth={2}
              strokeDasharray="5 5"
              fill="transparent"
              animationDuration={2500}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
