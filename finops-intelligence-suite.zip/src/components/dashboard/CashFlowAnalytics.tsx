import { motion } from 'motion/react';
import { TrendingUp, TrendingDown, Zap } from 'lucide-react';
import { useFinancial } from '../../context/FinancialContext';

export function CashFlowAnalytics() {
  const { formatCurrency } = useFinancial();

  const metrics = [
    { label: 'Burn Rate', value: formatCurrency(12400), trend: '-2.4%', status: 'optimal', progress: 45 },
    { label: 'Runway', value: '14.2 Mo', trend: '+1.5 Mo', status: 'healthy', progress: 85 },
    { label: 'Op. Margin', value: '32.5%', trend: '+4.1%', status: 'improving', progress: 65 }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'optimal': return 'bg-emerald-500';
      case 'healthy': return 'bg-indigo-500';
      default: return 'bg-slate-400';
    }
  };

  return (
    <div className="dashboard-card p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h3 className="font-bold text-slate-900 text-[15px] tracking-tight">Runway Intelligence</h3>
          <p className="text-[11px] text-slate-500 font-medium mt-1">Strategic cash flow velocity audit</p>
        </div>
        <div className="w-8 h-8 rounded-lg bg-slate-50 flex items-center justify-center border border-slate-100">
           <Zap className="w-3.5 h-3.5 text-slate-400" />
        </div>
      </div>

      <div className="space-y-5">
        {metrics.map((metric, i) => (
          <div key={i} className="group cursor-pointer">
            <div className="flex justify-between items-center mb-2.5">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-widest">{metric.label}</span>
              <div className="flex items-center gap-2">
                 <span className={`text-[10px] font-bold flex items-center gap-1 ${
                  metric.trend.startsWith('+') ? 'text-emerald-500' : 'text-rose-500'
                }`}>
                  {metric.trend}
                </span>
                <div className={`w-1.5 h-1.5 rounded-full ${getStatusColor(metric.status)} shadow-[0_0_8px_rgba(0,0,0,0.1)]`} />
              </div>
            </div>
            <div className="flex items-center gap-4">
              <span className="text-xl font-bold text-slate-900 tracking-tight tabular-nums min-w-[80px]">{metric.value}</span>
              <div className="flex-1 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: `${metric.progress}%` }}
                  transition={{ duration: 1.2, delay: i * 0.1, ease: "easeOut" }}
                  className={`h-full rounded-full ${getStatusColor(metric.status)}`}
                />
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6 pt-5 border-t border-slate-100">
        <button className="w-full h-10 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl text-[11px] font-bold text-slate-900 uppercase tracking-wider transition-all shadow-sm active:scale-95">
          Generate Strategic Forecast
        </button>
      </div>
    </div>
  );
}
