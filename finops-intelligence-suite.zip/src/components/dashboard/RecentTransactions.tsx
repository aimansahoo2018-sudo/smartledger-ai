import { ArrowRight, CheckCircle2, Clock, XCircle } from 'lucide-react';
import { useFinancial } from '../../context/FinancialContext';

export function RecentTransactions() {
  const { expenses, formatCurrency } = useFinancial();
  
  const transactions = [
    ...expenses.slice(0, 3).map(e => ({
      id: e.id,
      name: e.vendor,
      date: e.date,
      amount: e.amount,
      status: 'Paid',
      type: 'Expense'
    })),
    { id: 'inv-1', name: 'Nexus Digital', date: '2024-05-14', amount: 5400, status: 'Pending', type: 'Income' },
    { id: 'inv-2', name: 'Vogue Dynamics', date: '2024-05-13', amount: 12000, status: 'Paid', type: 'Income' },
  ].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  return (
    <div className="dashboard-card p-0 overflow-hidden shadow-sm">
      <div className="p-5 border-b border-slate-100 flex justify-between items-center bg-white/80 backdrop-blur-md sticky top-0 z-10 font-[Inter]">
        <div>
          <h3 className="font-bold text-slate-900 text-base tracking-tight">Recent Activity</h3>
          <p className="text-[11px] text-slate-500 font-medium mt-0.5">Real-time financial synchronization</p>
        </div>
        <button className="h-9 px-3.5 rounded-xl text-[11px] font-bold text-slate-900 uppercase tracking-wider border border-slate-200 hover:bg-slate-50 transition-all flex items-center gap-2 group active:scale-95 shadow-sm">
          Full Ledger <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
        </button>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-50/40">
              <th className="px-6 py-3.5 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Counterparty</th>
              <th className="px-6 py-3.5 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Type</th>
              <th className="px-6 py-3.5 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Date</th>
              <th className="px-6 py-3.5 text-[10px] font-bold text-slate-400 uppercase tracking-widest text-right">Amount</th>
              <th className="px-6 py-3.5 text-[10px] font-bold text-slate-400 uppercase tracking-widest text-right">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {transactions.map((tx) => (
              <tr key={tx.id} className="hover:bg-slate-50/50 transition-colors group cursor-pointer">
                <td className="px-6 py-4.5">
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-[11px] shadow-sm border ${
                      tx.type === 'Income' ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 'bg-slate-100 text-slate-600 border-slate-200'
                    }`}>
                      {tx.name.charAt(0)}
                    </div>
                    <div>
                        <p className="text-[13px] font-bold text-slate-900 tracking-tight">{tx.name}</p>
                        <p className="text-[10px] font-medium text-slate-400">TXN-{tx.id.substring(0, 6).toUpperCase()}</p>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4.5">
                  <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded border ${
                    tx.type === 'Income' ? 'text-emerald-600 bg-emerald-50 border-emerald-100' : 'text-slate-500 bg-slate-50 border-slate-100'
                  }`}>
                    {tx.type}
                  </span>
                </td>
                <td className="px-6 py-4.5 text-[12px] font-medium text-slate-500">
                  {new Date(tx.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                </td>
                <td className={`px-6 py-4.5 text-[13px] font-bold text-right tabular-nums ${
                  tx.type === 'Income' ? 'text-emerald-600' : 'text-slate-900'
                }`}>
                  {tx.type === 'Income' ? '+' : '-'}{formatCurrency(tx.amount)}
                </td>
                <td className="px-6 py-4.5 text-right">
                  <div className="flex justify-end">
                    {tx.status === 'Paid' ? (
                      <div className="flex items-center gap-1.5 px-2 py-0.5 bg-emerald-50 text-emerald-600 rounded-lg border border-emerald-100 shadow-sm">
                        <CheckCircle2 className="w-3 h-3" />
                        <span className="text-[9px] font-bold uppercase tracking-widest">Settled</span>
                      </div>
                    ) : (
                      <div className="flex items-center gap-1.5 px-2 py-0.5 bg-amber-50 text-amber-600 rounded-lg border border-amber-100 shadow-sm">
                        <Clock className="w-3 h-3" />
                        <span className="text-[9px] font-bold uppercase tracking-widest">Pending</span>
                      </div>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
