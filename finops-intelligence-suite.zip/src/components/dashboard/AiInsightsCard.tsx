import { useState } from 'react';
import { Sparkles, ArrowRight, X, Loader2, RefreshCw } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { generateExecutiveInsight } from '../../services/geminiService';
import { useFinancial } from '../../context/FinancialContext';

export function AiInsightsCard() {
  const { totals, expenses, formatCurrency, setActiveTab } = useFinancial();
  const [isGenerating, setIsGenerating] = useState(false);
  const [insights, setInsights] = useState<string[]>([
    `Revenue velocity at +15.7% — outpacing projections.`,
    `Potential optimization identified: ${formatCurrency(12400)} in VAT.`,
    `Burn resilient: Current assets secure 6 months runway.`,
  ]);

  const handleRefresh = async () => {
    setIsGenerating(true);
    try {
      const summary = `Revenue: ${totals.revenue}, Total Expenses: ${totals.expenses}, Anomaly count: ${expenses.filter(e => e.isAnomaly).length}`;
      const context = `User business dashboard summary: ${summary}. Analysis of recent ${expenses.length} transactions. Focus on optimization.`;
      const newBullets = await generateExecutiveInsight(context);
      setInsights(newBullets.slice(0, 3));
    } catch (error) {
      console.error("AI Insight Error:", error);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="bg-[#0f172a] rounded-[28px] p-6 h-full relative overflow-hidden group flex flex-col border border-white/5 shadow-2xl shadow-slate-950/20">
      <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500 opacity-[0.08] blur-[80px] pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-24 h-24 bg-indigo-500 opacity-[0.08] blur-[60px] pointer-events-none" />
      
      <div className="flex items-center justify-between mb-6 relative z-10">
        <div className="flex items-center gap-2.5">
          <div className="p-2 bg-emerald-500/10 rounded-lg border border-emerald-500/10">
            <Sparkles className="w-4 h-4 text-emerald-400 fill-emerald-400/10 animate-pulse" />
          </div>
          <div>
            <h3 className="font-bold text-white text-[13px] tracking-tight">Strategy Intelligence</h3>
            <p className="text-[10px] text-slate-500 font-bold uppercase tracking-[0.1em] mt-0.5">Autonomous core audit</p>
          </div>
        </div>
        <button 
          onClick={handleRefresh}
          disabled={isGenerating}
          className="p-1.5 hover:bg-white/5 rounded-lg flex items-center justify-center transition-colors text-slate-400 border border-white/5 group active:scale-95"
        >
          {isGenerating ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <RefreshCw className="w-3.5 h-3.5 group-hover:rotate-180 transition-transform duration-500" />}
        </button>
      </div>

      <div className="space-y-3 mb-6 flex-1 relative z-10">
        <AnimatePresence mode="popLayout">
          {insights.map((insight, i) => (
            <motion.div 
              key={insight}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, x: 10 }}
              transition={{ delay: i * 0.1, duration: 0.4 }}
              className="px-4 py-3.5 rounded-2xl bg-white/[0.03] border border-white/[0.03] hover:bg-white/[0.05] hover:border-white/[0.05] transition-all cursor-pointer group/item"
            >
              <div className="flex gap-3">
                <div className="w-1 h-1 rounded-full bg-emerald-400 mt-1.5 flex-shrink-0 shadow-[0_0_8px_rgba(52,211,153,0.3)] group-hover/item:scale-125 transition-transform" />
                <p className="text-slate-300 text-[12px] leading-relaxed font-medium">
                  {insight}
                </p>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      <button 
        onClick={() => setActiveTab('ai-assistant')}
        className="w-full bg-white text-slate-900 py-3 rounded-2xl text-[11px] font-bold uppercase tracking-widest flex items-center justify-center gap-2 transition-all hover:bg-emerald-400 hover:scale-[1.02] active:scale-95 shadow-xl shadow-black/20 group relative z-20"
      >
        Strategic Advisory Hub
        <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
      </button>
    </div>
  );
}
