import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';
import { useFinancial } from '../../context/FinancialContext';

export function IncomeExpenseDonut({ timeframe, setTimeframe, totals }: { timeframe: string, setTimeframe: (t: string) => void, totals: any }) {
  const { formatCurrency } = useFinancial();
  const isYear = timeframe === 'This Year';
  const data = [
    { name: 'Income', value: isYear ? totals.revenue : totals.revenue / 12, color: '#10B981', bg: 'bg-emerald-500' },
    { name: 'Expense', value: isYear ? totals.expenses : totals.expenses / 12, color: '#0F172A', bg: 'bg-slate-900' },
  ];

  const total = data.reduce((acc, cur) => acc + cur.value, 0);

  return (
    <div className="dashboard-card p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
            <h3 className="font-bold text-slate-900 text-[15px] tracking-tight">EBITDA Distribution</h3>
            <p className="text-[11px] text-slate-500 font-medium mt-1">Operational margin health</p>
        </div>
        <select 
          value={timeframe}
          onChange={(e) => setTimeframe(e.target.value)}
          className="text-[10px] font-bold text-slate-600 bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 outline-none uppercase tracking-wider cursor-pointer hover:bg-white transition-all appearance-none"
        >
          <option>This Year</option>
          <option>This Month</option>
        </select>
      </div>

      <div className="h-44 relative">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              innerRadius={58}
              outerRadius={74}
              paddingAngle={6}
              dataKey="value"
              stroke="none"
              animationBegin={0}
              animationDuration={1500}
            >
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Pie>
            <Tooltip 
              contentStyle={{ 
                borderRadius: '12px', 
                border: '1px solid #f1f5f9', 
                boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)',
                fontSize: '11px',
                fontWeight: '700',
                padding: '8px 12px'
              }} 
              formatter={(value: any) => [formatCurrency(value), '']}
            />
          </PieChart>
        </ResponsiveContainer>
        <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
          <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest leading-none mb-1">Efficiency</p>
          <p className="text-xl font-bold text-slate-900 tracking-tight tabular-nums">
            {Math.round((data[0].value / total) * 100)}%
          </p>
        </div>
      </div>

      <div className="mt-4 space-y-2">
        {data.map((item) => (
          <div key={item.name} className="flex items-center justify-between p-2 rounded-xl border border-transparent hover:border-slate-100 hover:bg-slate-50/50 transition-all group">
            <div className="flex items-center gap-2.5">
              <div className={`w-1.5 h-1.5 rounded-full ${item.bg} shadow-sm`} />
              <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider group-hover:text-slate-900 transition-colors">{item.name}</span>
            </div>
            <span className="text-[13px] font-bold text-slate-900 tabular-nums">
              {formatCurrency(item.value)}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
