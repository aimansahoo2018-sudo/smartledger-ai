import { Smartphone, Monitor, ShoppingBag, Truck, Zap } from 'lucide-react';
import { motion } from 'motion/react';
import { Expense, useFinancial } from '../../context/FinancialContext';

export function TopExpensesList({ expenses }: { expenses: Expense[] }) {
  const { formatCurrency } = useFinancial();
  const totalSpend = expenses.reduce((sum, e) => sum + e.amount, 0);
  
  const displayExpenses = [
    { name: 'Marketing', amount: totalSpend * 0.28, percentage: 28, icon: ShoppingBag, color: 'text-pink-500' },
    { name: 'SaaS & Infrastructure', amount: totalSpend * 0.24, percentage: 24, icon: Monitor, color: 'text-blue-500' },
    { name: 'Operational Overheads', amount: totalSpend * 0.18, percentage: 18, icon: Zap, color: 'text-amber-500' },
    { name: 'Logistics', amount: totalSpend * 0.15, percentage: 15, icon: Truck, color: 'text-rose-500' },
    { name: 'Hardware', amount: totalSpend * 0.14, percentage: 14, icon: Smartphone, color: 'text-emerald-500' },
  ];

  return (
    <div className="dashboard-card p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
           <h3 className="font-bold text-slate-900 text-[15px] tracking-tight">CapEx Allocation</h3>
           <p className="text-[11px] text-slate-500 font-medium mt-1">High-velocity outflow auditing</p>
        </div>
      </div>

      <div className="space-y-5">
        {displayExpenses.map((expense, i) => (
          <div key={i} className="group cursor-pointer">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl flex items-center justify-center bg-slate-50 border border-slate-100 group-hover:bg-white group-hover:shadow-sm transition-all">
                  <expense.icon className={`w-4 h-4 ${expense.color}`} />
                </div>
                <div>
                  <p className="text-[13px] font-bold text-slate-900 tracking-tight">{expense.name}</p>
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{expense.percentage}% Share</p>
                </div>
              </div>
              <p className="text-[13px] font-bold text-slate-900 tabular-nums">{formatCurrency(expense.amount)}</p>
            </div>
            
            <div className="relative h-1.5 w-full bg-slate-50 rounded-full overflow-hidden">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${expense.percentage}%` }}
                transition={{ duration: 1.2, delay: i * 0.1, ease: "easeOut" }}
                className="absolute h-full rounded-full bg-slate-900 shadow-sm opacity-90"
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
