import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { FinancialProvider } from './context/FinancialContext';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <FinancialProvider>
      <App />
    </FinancialProvider>
  </StrictMode>,
);
